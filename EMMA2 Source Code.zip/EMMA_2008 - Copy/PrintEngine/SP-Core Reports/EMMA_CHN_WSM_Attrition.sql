IF OBJECT_ID('dbo.EMMA_CHN_WSM_Attrition') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.EMMA_CHN_WSM_Attrition
    IF OBJECT_ID('dbo.EMMA_CHN_WSM_Attrition') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.EMMA_CHN_WSM_Attrition >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.EMMA_CHN_WSM_Attrition >>>'
END
go

CREATE PROCEDURE EMMA_CHN_WSM_Attrition
     @JOBNO        INT
AS
BEGIN
  DECLARE
	@cCriteria1			VarChar(254),
	@cDateFrom			VarChar(30),
	@cDateTo				VarChar(30),
	@dDateFrom			Datetime,
	@dDateTo				Datetime,
	@cBuffer				VarChar(254),
	@cBilledFlag		Char(1)

SELECT @cCriteria1 = criteria1_txt
	FROM tprintqueue
	WHERE print_job_no = @jobno

SELECT @dDateFrom = GetDate(), @cDateTo = GetDate()

IF CharIndex('TIME_STAMP', @cCriteria1) < 1
	SELECT @cBilledFlag = 'N'
ELSE
	SELECT @cBilledFlag = 'Y'

IF @cBilledFlag = 'Y'
	BEGIN	
		SELECT @cBuffer = SubString(@cCriteria1, CharIndex('#', @cCriteria1) + 1, 254)
		SELECT @cDateFrom = SubString(@cBuffer, 1, CharIndex('#', @cBuffer) - 1)
		SELECT @dDateFrom = Convert(Datetime, @cDateFrom)

		IF CharIndex('TIME_STAMP', @cBuffer) > 0
			BEGIN
				SELECT @cBuffer = SubString(@cBuffer, CharIndex('TIME_STAMP', @cBuffer), 254)
				SELECT @cBuffer = SubString(@cBuffer, CharIndex('#', @cBuffer) + 1, 254)
				SELECT @cDateTo = SubString(@cBuffer, 1, CharIndex('#', @cBuffer) - 1)
				SELECT @dDateTo = Convert(Datetime, @cDateTo)
			END
		ELSE
			SELECT @dDateTo = DateAdd(Day, 1, @dDateFrom)

	END

    


     SELECT    A.POLICYCERT_NO,
               A.END_EFF_DATE,
               A.RIDER_NO,
               A.CAMPAIGN_CD,
               B.CAMPAIGN_DESC_TEXT,
               B.SPONSOR_NO,
               B.SPONSOR_NAME,
               A.PLAN_NO,
               A.POLICY_EFF_DATE,
               A.PRM_PER_PERIOD_AMT,
               A.CANCEL_DATE,
               A.CAN_REASON_TEXT,
               A.STATUS_CD,
               A.LATEST_VERSION_FG,
               A.TIME_STAMP,
               FULLNAME  = H.PHOLD_FAMILY_NAME + ", " + H.PHOLD_GIVEN_NAME,
               AGE       = CASE
                              WHEN substring(convert(char,convert(datetime,H.PHOLD_BIRTH_DATE),102),6,5) > substring(convert(char,getdate(), 102),6,5) THEN DATEDIFF(YEAR,H.PHOLD_BIRTH_DATE, GETDATE()) -1
                              ELSE DATEDIFF(YEAR,H.PHOLD_BIRTH_DATE, GETDATE()) -1
                           END,
               C.BILL_INTERVAL_CD,
               G.PLAN_DESC_TEXT,
               Lifespan1 = CASE WHEN DateDiff(year, a.policy_eff_date, a.cancel_date) < 365 THEN 1 ELSE 0 END,
               Lifespan2 = CASE WHEN DateDiff(year, a.policy_eff_date, a.cancel_date) >= 365
               		AND DateDiff(year, a.policy_eff_date, a.cancel_date) >= 365 THEN 1 ELSE 0 END,
               Lifespan3 = CASE WHEN DateDiff(year, a.policy_eff_date, a.cancel_date) > 730 THEN 1 ELSE 0 END,
               MonthlyAmt = IsNull(CASE WHEN c.bill_interval_cd = 'A' THEN a.prm_per_period_amt / 12
                 WHEN c.bill_interval_cd = 'H' THEN a.prm_per_period_amt / 2
                 WHEN c.bill_interval_cd = 'Q' THEN a.prm_per_period_amt / 3
                 WHEN c.bill_interval_cd = '4' THEN a.prm_per_period_amt * 13 / 12
                 WHEN c.bill_interval_cd = 'F' THEN a.prm_per_period_amt * 26 / 12
                 WHEN c.bill_interval_cd = 'W' THEN a.prm_per_period_amt * 52 / 12 END, 0),
               BenefitLevel = Convert(Money, 0),
               FreeCover = Convert(Int, 0)
     INTO			 #tmpOut1
     FROM      TPOLICYCERTRIDER  A,
               TCAMPDETS B,
               TPAYMENTDETS C,
               TPOLICYCERT D,
               TCAMPPLAN E,
               TPLANDETS G,
               TPOLICYCERTHOLDER H
     WHERE     A.STATUS_CD         = "C"
     AND       A.LATEST_VERSION_FG = "Y"
		 AND 			((@cBilledFlag = 'Y' AND a.time_stamp >= @dDateFrom AND a.time_stamp < @dDateTo) OR (@cBilledFlag = 'N'))
     AND       B.CAMPAIGN_CD       = A.CAMPAIGN_CD
     AND       C.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       C.END_EFF_DATE      = A.END_EFF_DATE
     AND       D.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       E.CAMPAIGN_CD       = A.CAMPAIGN_CD
     AND       E.PLAN_NO           = A.PLAN_NO
     AND       E.END_EFF_DATE      = (  SELECT    MAX(F.END_EFF_DATE)
                                        FROM      TCAMPPLAN F
                                        WHERE     F.CAMPAIGN_CD       = A.CAMPAIGN_CD
                                        AND       F.PLAN_NO           = A.PLAN_NO
                                        AND       F.END_EFF_DATE      <= A.END_EFF_DATE)
     AND       G.PLAN_NO           = E.PLAN_NO
     AND       G.END_EFF_DATE      = E.END_EFF_DATE
     AND       H.POLICY_HOLDER_NO  = D.POLICY_HOLDER_NO

UPDATE #tmpOut1
	SET BenefitLevel = IsNull((SELECT Sum(x.benefit_amt) FROM tpolicycertpremium x WHERE x.policycert_no = a.policycert_no
		AND x.end_eff_date = a.end_eff_date AND x.name_insured_no = 0 AND x.rider_no = a.rider_no), 0),
	FreeCover = (SELECT Count(*) FROM tpolicycertpremium y WHERE y.policycert_no = a.policycert_no
		AND y.end_eff_date = a.end_eff_date AND y.name_insured_no = 0 AND y.rider_no = a.rider_no
		AND y.premium_amt = 0)
	FROM #tmpOut1 a

SELECT * FROM #tmpOut1

		
END
go

GRANT EXECUTE ON dbo.EMMA_CHN_WSM_Attrition TO public
go

IF OBJECT_ID('dbo.EMMA_CHN_WSM_Attrition') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.EMMA_CHN_WSM_Attrition >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.EMMA_CHN_WSM_Attrition >>>'
go
