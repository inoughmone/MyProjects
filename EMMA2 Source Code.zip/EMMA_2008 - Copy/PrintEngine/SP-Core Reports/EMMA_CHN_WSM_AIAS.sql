IF OBJECT_ID('dbo.EMMA_CHN_WSM_AIAS') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.EMMA_CHN_WSM_AIAS
    IF OBJECT_ID('dbo.EMMA_CHN_WSM_AIAS') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.EMMA_CHN_WSM_AIAS >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.EMMA_CHN_WSM_AIAS >>>'
END
go

CREATE PROCEDURE EMMA_CHN_WSM_AIAS
     @JOBNO        INT

AS
BEGIN


     DECLARE  @CRITERIA1_TXT 	CHAR(254),
              @DATESTRING    	CHAR(40),
              @START         	DATETIME,
              @END           	DATETIME,
              @AMOUNT					MONEY,
              
							@cCriteria1			VarChar(254),
							@cDateFrom			VarChar(30),
							@cDateTo				VarChar(30),
							@dDateFrom			Datetime,
							@dDateTo				Datetime,
							@cBuffer				VarChar(254),
							@cBilledFlag		Char(1)
                    
--      SELECT    @CRITERIA1_TXT  = A.CRITERIA1_TXT,
-- 							 @AMOUNT         = A.PRINT_AMT 
--      FROM      TPRINTQUEUE A
--      WHERE     A.PRINT_JOB_NO  = @JOBNO                    

SELECT @cCriteria1 = criteria1_txt, @amount = print_amt
	FROM tprintqueue
	WHERE print_job_no = @jobno
	
SELECT @dDateFrom = GetDate(), @cDateTo = GetDate()

IF CharIndex('BILLED_ON_DATE', @cCriteria1) < 1
	SELECT @cBilledFlag = 'N'
ELSE
	SELECT @cBilledFlag = 'Y'

IF @cBilledFlag = 'Y'
	BEGIN	
		SELECT @cBuffer = SubString(@cCriteria1, CharIndex('#', @cCriteria1) + 1, 254)
		SELECT @cDateFrom = SubString(@cBuffer, 1, CharIndex('#', @cBuffer) - 1)
		SELECT @dDateFrom = Convert(Datetime, @cDateFrom)

		IF CharIndex('BILLED_ON_DATE', @cBuffer) > 0
			BEGIN
				SELECT @cBuffer = SubString(@cBuffer, CharIndex('BILLED_ON_DATE', @cBuffer), 254)
				SELECT @cBuffer = SubString(@cBuffer, CharIndex('#', @cBuffer) + 1, 254)
				SELECT @cDateTo = SubString(@cBuffer, 1, CharIndex('#', @cBuffer) - 1)
				SELECT @dDateTo = Convert(Datetime, @cDateTo)
			END
		ELSE
			SELECT @dDateTo = DateAdd(Day, 1, @dDateFrom)

	END

     SELECT    A.CAMPAIGN_CD,
               A.BILLED_ON_DATE,
               A.BILL_INTERVAL_CD,
               CountOfPOLICY_NO    = Count(100),
               CAMPAIGN_DESC_TEXT  = SPACE(50),
               IntervalCode        = SPACE(20),
               AMOUNT              = @AMOUNT,
               PRINT_AMT           = @AMOUNT
     INTO      #TEMP1
     FROM      TBILLTRXN A 
     WHERE     A.REJECT_FG    = "N"
     AND       NOT (A.BILL_INTERVAL_CD IS NULL)
     AND ((@cBilledFlag = 'Y' AND a.billed_on_date >= @dDateFrom AND a.billed_on_date < @dDateTo) OR (@cBilledFlag = 'N'))
     GROUP by  A.CAMPAIGN_CD,
               A.BILLED_ON_DATE,
               A.BILL_INTERVAL_CD
     
     UPDATE    #TEMP1
     SET       CAMPAIGN_DESC_TEXT  = B.CAMPAIGN_DESC_TEXT
     FROM      #TEMP1 A,
               TCAMPDETS B
     WHERE     B.CAMPAIGN_CD  = A.CAMPAIGN_CD 
     
     UPDATE    #TEMP1
     SET       IntervalCode   =    Case 
                                      when BILL_INTERVAL_CD = "A" Then "Annual"
                                      when BILL_INTERVAL_CD = "H" then "HalfYearly"
                                      when BILL_INTERVAL_CD = "Q" then "Quarterly"
                                      when BILL_INTERVAL_CD = "M" then "Monthly"
                                      when BILL_INTERVAL_CD = "4" then "Four Weekly"
                                      when BILL_INTERVAL_CD = "F" then "Fourth Nightly"
                                      when BILL_INTERVAL_CD = "W" then "Weekly"
                                      when BILL_INTERVAL_CD = " " then "0"
                                      Else
                                         BILL_INTERVAL_CD
                                  End,
               AMOUNT         =    Case 
                                      when BILL_INTERVAL_CD = "A" Then (AMOUNT * CountOfPOLICY_NO)
                                      when BILL_INTERVAL_CD = "H" then (AMOUNT * CountOfPOLICY_NO)/2
                                      when BILL_INTERVAL_CD = "Q" then (AMOUNT * CountOfPOLICY_NO)/4
                                      when BILL_INTERVAL_CD = "M" then (AMOUNT * CountOfPOLICY_NO)/12
                                      when BILL_INTERVAL_CD = "4" then (AMOUNT * CountOfPOLICY_NO)/13
                                      when BILL_INTERVAL_CD = "F" then (AMOUNT * CountOfPOLICY_NO)/26
                                      when BILL_INTERVAL_CD = "W" then (AMOUNT * CountOfPOLICY_NO)/52
                                      Else
                                         (AMOUNT * CountOfPOLICY_NO)
                                  End
     FROM      #TEMP1 A
     
     --SELECT *
     SELECT CAMPAIGN_CD, BILL_INTERVAL_CD, CountOfPOLICY_NO, CAMPAIGN_DESC_TEXT, IntervalCode, 
     				convert(numeric,PRINT_AMT) as PRINT_AMT,
     				convert(numeric,AMOUNT) as AMOUNT, 
     				convert(numeric,(PRINT_AMT * CountOfPOLICY_NO)) as TOTAL_AMOUNT,            
            
            --for billing date "mm/yyyy"            
            (replicate ('0', 2 - char_length(convert(varchar,DATEPART(MONTH, BILLED_ON_DATE)))) + convert(varchar,(DATEPART(MONTH, BILLED_ON_DATE)))
            +"-"+
            convert(varchar,(DATEPART(YEAR, BILLED_ON_DATE)))) as BILLED_ON_DATE,
	    	 		
            --for current date "mm/dd/yyyy"
            (replicate ('0', 2 - char_length(convert(varchar,DATEPART(MONTH, GETDATE())))) + convert(varchar,(DATEPART(MONTH, GETDATE())))
            +"-"+
            replicate ('0', 2 - char_length(convert(varchar,DATEPART(DAY, GETDATE())))) + convert(varchar,(DATEPART(DAY, GETDATE())))
            +"-"+
            convert(varchar,(DATEPART(YEAR, GETDATE())))) as TIME_STAMP

     FROM #TEMP1
END
go

GRANT EXECUTE ON dbo.EMMA_CHN_WSM_AIAS TO public
go

IF OBJECT_ID('dbo.EMMA_CHN_WSM_AIAS') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.EMMA_CHN_WSM_AIAS >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.EMMA_CHN_WSM_AIAS >>>'
go
