print "Before"
go
sp_help WSM_PREMIUM_UPGRADED
go

IF OBJECT_ID('dbo.WSM_PREMIUM_UPGRADED') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_PREMIUM_UPGRADED
    IF OBJECT_ID('dbo.WSM_PREMIUM_UPGRADED') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_PREMIUM_UPGRADED >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_PREMIUM_UPGRADED >>>'
END
go

/*
****************************************************************************************************
TITLE           : WSM_PREMIUM_UPGRADED
AUTHOR          : MPHASIS
DATE            : 07/25/2006
DESCRIPTION     : THIS STORED PROCEDURE IS USED To GET AGE RATED PREMIUM
USE FOR         :
****************************************************************************************************
*/

CREATE PROCEDURE dbo.WSM_PREMIUM_UPGRADED
     @POLICYCERT_NO      VARCHAR(14),
     @END_EFF_DATE       DATETIME,
     @RIDER_NO           SMALLINT,
     @REF_GROUP_CD       CHAR(6)   = "061000"
AS
BEGIN
     DECLARE   @PLAN_NO             VARCHAR(5),
               @PLAN_EFF_DATE       DATETIME,
               @Base_PLAN_NO        VARCHAR(5),
               @Base_PLAN_EFF_DATE  DATETIME,
               @PLAN_LAYER_CD       VARCHAR(10),
               @PLAN_RATE_CAT_CD    VARCHAR(10),
               @PRODUCT_CD          VARCHAR(6)


     SELECT    @PLAN_NO            = A.PLAN_NO
     FROM      TPOLICYCERTRIDER A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.END_EFF_DATE      = @END_EFF_DATE
     AND       A.RIDER_NO          = @RIDER_NO

     SELECT    @PLAN_EFF_DATE      = MAX(END_EFF_DATE)
     FROM      TPLANPRODUCT
     WHERE     PLAN_NO             = @PLAN_NO
     AND       END_EFF_DATE        <= @END_EFF_DATE
     
     SELECT    @Base_PLAN_NO       = A.PLAN_NO
     FROM      TPOLICYCERTRIDER A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.RIDER_NO          = 0
     AND       A.LATEST_VERSION_FG = 'Y'
     
     SELECT    @Base_PLAN_EFF_DATE = MAX(END_EFF_DATE)
     FROM      TPLANPRODUCT
     WHERE     PLAN_NO             = @Base_PLAN_NO
     AND       END_EFF_DATE        <= @END_EFF_DATE
     
     SELECT    @PRODUCT_CD = A.PRODUCT_CD,
               @PLAN_LAYER_CD =  A.PLAN_LAYER_CD,
               @PLAN_RATE_CAT_CD = A.PLAN_RATE_CAT_CD
     FROM      TPOLICYCERTPREMIUM A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.END_EFF_DATE      = @END_EFF_DATE
     AND       A.RIDER_NO          = @RIDER_NO
     AND       A.NAME_INSURED_NO   = 0
     AND       A.PLAN_NO           = @PLAN_NO

     SELECT    A.PLAN_NO, A.END_EFF_DATE, A.PRODUCT_CD, A.PLAN_LAYER_CD, A.PLAN_RATE_CAT_CD, A.PLAN_RATE_BAND_CD,
               A.LOWER_AGE_CNT, A.UPPER_AGE_CNT,
               A.PREMIUM_AMT AS PREMIUM,
               BASE_INDIVIDUAL_PREMIUM = CONVERT(MONEY, 0),
               BASE_COUPLE_PREMIUM = CONVERT(MONEY, 0),
               BASE_FAMILY_PREMIUM = CONVERT(MONEY, 0),
               INDIVIDUAL_PREMIUM = CONVERT(MONEY, 0),
               COUPLE_PREMIUM = CONVERT(MONEY, 0),
               FAMILY_PREMIUM = CONVERT(MONEY, 0)
     INTO      #TMP_PREMIUM
     FROM      TPREMLOOKUP A
     WHERE     A.PLAN_NO = @PLAN_NO
     AND       A.END_EFF_DATE = @PLAN_EFF_DATE
     AND       A.PRODUCT_CD = @PRODUCT_CD
     AND       A.PLAN_LAYER_CD =  @PLAN_LAYER_CD
     AND       A.PLAN_RATE_CAT_CD = @PLAN_RATE_CAT_CD
     
     UPDATE		 #TMP_PREMIUM      
     SET			 INDIVIDUAL_PREMIUM = B.PREMIUM_AMT                      		     					      		     			 
    FROM       #TMP_PREMIUM A, TPREMLOOKUP B
    WHERE      B.PLAN_NO = @PLAN_NO
     AND       B.END_EFF_DATE = @PLAN_EFF_DATE
     AND       A.PRODUCT_CD = B.PRODUCT_CD
     AND       A.PLAN_LAYER_CD =  B.PLAN_LAYER_CD     
     AND       A.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
     AND       B.PLAN_RATE_CAT_CD = 'INDIVIDUAL'
     
     UPDATE		 #TMP_PREMIUM      
     SET			 COUPLE_PREMIUM = B.PREMIUM_AMT                      		     					      		     			 
    FROM       #TMP_PREMIUM A, TPREMLOOKUP B
    WHERE      B.PLAN_NO = @PLAN_NO
     AND       B.END_EFF_DATE = @PLAN_EFF_DATE
     AND       A.PRODUCT_CD = B.PRODUCT_CD
     AND       A.PLAN_LAYER_CD =  B.PLAN_LAYER_CD     
     AND       A.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
     AND       B.PLAN_RATE_CAT_CD = 'COUPLEPLN'
     
     UPDATE		 #TMP_PREMIUM      
     SET			 FAMILY_PREMIUM = B.PREMIUM_AMT                      		     					      		     			 
    FROM       #TMP_PREMIUM A, TPREMLOOKUP B
    WHERE      B.PLAN_NO = @PLAN_NO
     AND       B.END_EFF_DATE = @PLAN_EFF_DATE
     AND       A.PRODUCT_CD = B.PRODUCT_CD
     AND       A.PLAN_LAYER_CD =  B.PLAN_LAYER_CD     
     AND       A.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
     AND       B.PLAN_RATE_CAT_CD = 'FAMILYPLAN'
     --Get base plan age premium
     IF @RIDER_NO > 0
     BEGIN
         UPDATE    #TMP_PREMIUM
         SET       BASE_INDIVIDUAL_PREMIUM = B.PREMIUM_AMT                                     
         FROM      #TMP_PREMIUM A, TPREMLOOKUP B
         WHERE     B.PLAN_NO = @Base_PLAN_NO
         AND       B.END_EFF_DATE = @Base_PLAN_EFF_DATE
         AND       A.PRODUCT_CD = B.PRODUCT_CD
         AND       A.PLAN_LAYER_CD =  B.PLAN_LAYER_CD         
         AND       A.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
         AND       B.PLAN_RATE_CAT_CD = 'INDIVIDUAL'
         
         UPDATE    #TMP_PREMIUM
         SET       BASE_COUPLE_PREMIUM = B.PREMIUM_AMT                                     
         FROM      #TMP_PREMIUM A, TPREMLOOKUP B
         WHERE     B.PLAN_NO = @Base_PLAN_NO
         AND       B.END_EFF_DATE = @Base_PLAN_EFF_DATE
         AND       A.PRODUCT_CD = B.PRODUCT_CD
         AND       A.PLAN_LAYER_CD =  B.PLAN_LAYER_CD         
         AND       A.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
         AND       B.PLAN_RATE_CAT_CD = 'COUPLEPLN'
         
         UPDATE    #TMP_PREMIUM
         SET       BASE_FAMILY_PREMIUM = B.PREMIUM_AMT                                     
         FROM      #TMP_PREMIUM A, TPREMLOOKUP B
         WHERE     B.PLAN_NO = @Base_PLAN_NO
         AND       B.END_EFF_DATE = @Base_PLAN_EFF_DATE
         AND       A.PRODUCT_CD = B.PRODUCT_CD
         AND       A.PLAN_LAYER_CD =  B.PLAN_LAYER_CD         
         AND       A.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
         AND       B.PLAN_RATE_CAT_CD = 'FAMILYPLAN'
     END
     
     SELECT #TMP_PREMIUM.PLAN_NO, #TMP_PREMIUM.END_EFF_DATE, #TMP_PREMIUM.PRODUCT_CD, 
            #TMP_PREMIUM.PLAN_LAYER_CD, #TMP_PREMIUM.PLAN_RATE_CAT_CD, #TMP_PREMIUM.PLAN_RATE_BAND_CD, 
            #TMP_PREMIUM.LOWER_AGE_CNT, #TMP_PREMIUM.UPPER_AGE_CNT, 
            #TMP_PREMIUM.INDIVIDUAL_PREMIUM, #TMP_PREMIUM.COUPLE_PREMIUM,#TMP_PREMIUM.FAMILY_PREMIUM,
            #TMP_PREMIUM.BASE_INDIVIDUAL_PREMIUM,#TMP_PREMIUM.BASE_COUPLE_PREMIUM,#TMP_PREMIUM.BASE_FAMILY_PREMIUM
     FROM #TMP_PREMIUM
     ORDER BY LOWER_AGE_CNT, UPPER_AGE_CNT
                
END

go
IF OBJECT_ID('dbo.WSM_PREMIUM_UPGRADED') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_PREMIUM_UPGRADED >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_PREMIUM_UPGRADED >>>'
go
GRANT EXECUTE ON dbo.WSM_PREMIUM_UPGRADED TO userall 
go

print "After"
go
sp_help WSM_PREMIUM_UPGRADED
go
