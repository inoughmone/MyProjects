print "Before"
go
sp_help WSM_NB5_MASTER
go

IF OBJECT_ID('dbo.WSM_NB5_MASTER') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_NB5_MASTER
    IF OBJECT_ID('dbo.WSM_NB5_MASTER') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_NB5_MASTER >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_NB5_MASTER >>>'
END
go
/*
****************************************************************************************************
TITLE           : WSM_NB5_MASTER
AUTHOR          : MPHASIS
DATE            : 5/12/2006
DESCRIPTION     : THIS STORED PROCEDURE IS USED AS MAIN SP FOR WSM_NB5 - POLICY SCHEDULE - NEW BUSINESS


USE FOR                 :
****************************************************************************************************
*/

CREATE PROCEDURE dbo.WSM_NB5_MASTER
     @POLICYCERT_NO   VARCHAR(14),
     @END_EFF_DATE     DATETIME,
     @RIDER_NO        SMALLINT,
     @IPRINTJOB     INT,
     @REF_GROUP_CD  CHAR(6)   = "061000"
AS
BEGIN
     DECLARE   @CSTATECITY    VARCHAR(37),
               @CADDR1        VARCHAR(186),
               @CADDR2        VARCHAR(92),
               @CPFNAME1      VARCHAR(83),
               @CPFNAME2      VARCHAR(45),
               @CIFNAME1      VARCHAR(83),
               @CIFNAME2      VARCHAR(45)

     -- get named insured ----------
     SELECT    A.POLICYCERT_NO,
               A.END_EFF_DATE,
               A.RIDER_NO,
               POLICY_EFF_DATE     = DATEADD(year, -1, A.POLICY_REN_DATE ),
               POL_EXP_DATE        = CONVERT(DATETIME, CASE
                                                            WHEN A.POLICY_REN_DATE IS NULL THEN NULL
                                                            ELSE
                                                                 DATEADD(DAY, -1, A.POLICY_REN_DATE )
                                                       END),
               A.PLAN_NO,
               A.USERID_CD,
               APP_ENTRY_DATE      = A.APPL_RECEIVED_DATE,
               POLICY_HOLDER_NO    = CONVERT(INT, NULL),
               PHOLD_TITLE_NAME    = CONVERT(CHAR(5), ''),
               PHOLD_M_INIT_NAME   = ' ',
               PHOLD_GIVEN_NAME    = CONVERT(VARCHAR(30), ''),
               PHOLD_FAMILY_NAME   = CONVERT(VARCHAR(45), ''),
               PHOLD_POST_CD       = CONVERT(VARCHAR(10), ''),
               PHOLD_STATE_ADDR    = CONVERT(VARCHAR(5), ''),
               PHOLD_CITY_ADDR     = CONVERT(VARCHAR(30), ''),
               PHOLD_1_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_2_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_3_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_4_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_FULLADDR      = CONVERT(VARCHAR(254), ''),
               PLAN_NAME           = CONVERT(VARCHAR(50), ''),
               PLAN_TYPE           = CONVERT(CHAR(1), '0'),
               DOCUMENT_ISO        = CONVERT(VARCHAR(20), '', NULL),
               A.ISSUING_BRNCH_CD
     INTO      #TMPOUT1
     FROM      TPOLICYCERTRIDER A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.END_EFF_DATE      = @END_EFF_DATE
     AND       A.RIDER_NO          = @RIDER_NO

     UPDATE    #TMPOUT1
     SET       PLAN_NAME           = B.PLAN_NAME
     FROM      #TMPOUT1 A,
               TPLANDETS B
     WHERE     A.PLAN_NO           = B.PLAN_NO
     AND       B.END_EFF_DATE      = (  SELECT    MAX(X.END_EFF_DATE)
                                        FROM      TPLANDETS X
                                        WHERE     X.PLAN_NO      = A.PLAN_NO
                                        AND       X.END_EFF_DATE <= A.END_EFF_DATE)

     ------- GET POLICYHOLDER INFORMATION
     UPDATE    #TMPOUT1
     SET       POLICY_HOLDER_NO    = B.POLICY_HOLDER_NO,
               PHOLD_TITLE_NAME    = C.PHOLD_TITLE_NAME,
               PHOLD_M_INIT_NAME   = C.PHOLD_M_INIT_NAME,
               PHOLD_GIVEN_NAME    = C.PHOLD_GIVEN_NAME,
               PHOLD_FAMILY_NAME   = C.PHOLD_FAMILY_NAME,
               PHOLD_POST_CD       = C.PHOLD_POST_CD,
               PHOLD_STATE_ADDR    = C.PHOLD_STATE_ADDR,
               PHOLD_CITY_ADDR     = C.PHOLD_CITY_ADDR,
               PHOLD_1_ADDR        = C.PHOLD_1_ADDR,
               PHOLD_2_ADDR        = C.PHOLD_2_ADDR,
               PHOLD_3_ADDR        = C.PHOLD_3_ADDR,
			         PHOLD_4_ADDR        = C.PHOLD_4_ADDR
     FROM      #TMPOUT1 A,
               TPOLICYCERT B,
               TPOLICYCERTHOLDER C
     WHERE     A.POLICYCERT_NO     = B.POLICYCERT_NO
     AND       B.POLICY_HOLDER_NO  = C.POLICY_HOLDER_NO


     SELECT    @CSTATECITY    = CASE
                                   WHEN PHOLD_STATE_ADDR IN ('', NULL) OR PHOLD_CITY_ADDR IN ('', NULL) THEN
                                        PHOLD_STATE_ADDR +  PHOLD_CITY_ADDR
                                   ELSE
                                        PHOLD_STATE_ADDR + ', ' + PHOLD_CITY_ADDR END,
               @CADDR1        = CASE
                                   WHEN PHOLD_1_ADDR IN ('', NULL) OR PHOLD_2_ADDR IN ('', NULL) THEN
                                        PHOLD_1_ADDR + PHOLD_2_ADDR
                                   ELSE
                                        PHOLD_1_ADDR + ', ' + PHOLD_2_ADDR END,
               @CADDR2        = CASE
                                   WHEN PHOLD_3_ADDR IN ('', NULL) OR PHOLD_4_ADDR IN ('', NULL) THEN
                                        PHOLD_3_ADDR + PHOLD_4_ADDR
                                   ELSE
                                        PHOLD_3_ADDR + ', ' + PHOLD_4_ADDR END,
               @CPFNAME1      = CASE
                                   WHEN PHOLD_GIVEN_NAME IN ('', NULL) OR PHOLD_M_INIT_NAME IN (' ', NULL) THEN
                                        PHOLD_GIVEN_NAME + RTRIM(PHOLD_M_INIT_NAME)
                                   ELSE
                                        PHOLD_GIVEN_NAME + ' ' + PHOLD_M_INIT_NAME END,
               @CPFNAME2      = PHOLD_FAMILY_NAME
     FROM      #TMPOUT1

     SELECT    @CADDR1   = CASE
                              WHEN @CADDR1 IN ('', NULL) OR @CADDR2 IN ('', NULL) THEN
                                   @CADDR1 + @CADDR2
                              ELSE
                                   @CADDR1 + ','++ CHAR(13)+ CHAR(10) + + @CADDR2 END,
               @CPFNAME1 = CASE
                              WHEN @CPFNAME1 IN ('', NULL) OR @CPFNAME2 IN ('', NULL) THEN
                                   @CPFNAME2 + @CPFNAME1
                              ELSE
                                   @CPFNAME2 + ' ' + @CPFNAME1 END

     UPDATE    #TMPOUT1
     SET       PHOLD_FULLADDR = @CADDR1


     UPDATE    #TMPOUT1
     SET       DOCUMENT_ISO = (    SELECT    A.DOCUMENT_ISO
                                   FROM      TFORMLETTERS A,
                                             TPRINTQUEUE B
                                   WHERE     A.DOCUMENT_NAME     = B.DOCUMENT_NAME
                                   AND       B.POLICYCERT_NO     = @POLICYCERT_NO
                                   AND       B.PRINT_JOB_NO      = @IPRINTJOB)

     UPDATE    #TMPOUT1
     SET       PLAN_TYPE = CASE
                              WHEN (    SELECT    COUNT(DISTINCT NAME_INSURED_NO)
                                        FROM      TNAMEDINSURED X
                                        WHERE     X.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       X.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       X.RIDER_NO          = A.RIDER_NO) > 1 THEN '1' ELSE '0' END
     FROM #TMPOUT1 A


---------------Get the extra premium and total benefit amount.
    DECLARE   @PLAN_NO               CHAR(5),
              @ASS_PLAN_NO           CHAR(5),
              @CAMPAIGN_CD           CHAR(7),
              @ASS_CAMPAIGN_CD       CHAR(7),
              @PLAN_EFF_DATE         DATETIME,
              @ASS_PLAN_EFF_DATE     DATETIME,
              @PRODUCT_CD            CHAR(6),
              @EXT_PREMIUM_AMT       MONEY,
              @TOTAL_BENEFIT_AMT     MONEY 


    SELECT    @PLAN_NO            = A.PLAN_NO,
              @CAMPAIGN_CD        = A.CAMPAIGN_CD
    FROM      TPOLICYCERTRIDER A
    WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
    AND       A.END_EFF_DATE      = @END_EFF_DATE
    AND       A.RIDER_NO          = @RIDER_NO
    
    SELECT    @ASS_CAMPAIGN_CD = ASSOC_CAMP_CD
    FROM      TCAMPASSOCIATE
    WHERE     MASTER_CAMP_CD = @CAMPAIGN_CD
    
    
    SELECT      @ASS_PLAN_NO      = CP.PLAN_NO
    FROM        TCAMPPLAN CP      
    WHERE       CAMPAIGN_CD  = @ASS_CAMPAIGN_CD    
    AND         END_EFF_DATE = (SELECT MAX(END_EFF_DATE) FROM TCAMPPLAN WHERE CAMPAIGN_CD  = @ASS_CAMPAIGN_CD)
    
    

    SELECT    @PLAN_EFF_DATE      = MAX(END_EFF_DATE)
    FROM      TPLANPRODUCT
    WHERE     PLAN_NO             = @PLAN_NO
    AND       END_EFF_DATE        <= @END_EFF_DATE
    
    SELECT    @ASS_PLAN_EFF_DATE      = MAX(END_EFF_DATE)
    FROM      TPLANPRODUCT
    WHERE     PLAN_NO             = @ASS_PLAN_NO
    AND       END_EFF_DATE        <= @END_EFF_DATE
    
    SELECT    @PRODUCT_CD = PRODUCT_CD
    FROM      TPLANPRODUCT
    WHERE     PLAN_NO = @ASS_PLAN_NO
    AND       END_EFF_DATE = @ASS_PLAN_EFF_DATE
    AND       RATED_ITEM_FG = 'Y'
    
    SELECT    @TOTAL_BENEFIT_AMT = A.BENEFIT_AMT
    FROM      TPOLICYCERTPREMIUM A          
    WHERE     A.POLICYCERT_NO = @POLICYCERT_NO
    AND       A.END_EFF_DATE = @END_EFF_DATE
    AND       A.NAME_INSURED_NO = 0
    AND       A.RIDER_NO = @RIDER_NO
    AND       A.PRODUCT_CD = @PRODUCT_CD
    
            
    SELECT    @TOTAL_BENEFIT_AMT = @TOTAL_BENEFIT_AMT + B.BENEFIT_AMT
    FROM      TPOLICYCERTPREMIUM A,
              TPREMLOOKUP B
    WHERE     A.POLICYCERT_NO = @POLICYCERT_NO
    AND       A.END_EFF_DATE = @END_EFF_DATE
    AND       A.NAME_INSURED_NO = 0
    AND       A.RIDER_NO = @RIDER_NO
    AND       A.PRODUCT_CD = @PRODUCT_CD
    AND       B.PLAN_NO = @ASS_PLAN_NO
    AND       B.END_EFF_DATE = @ASS_PLAN_EFF_DATE
    AND       B.PRODUCT_CD = @PRODUCT_CD
    AND       B.PLAN_LAYER_CD = A.PLAN_LAYER_CD
    AND       B.PLAN_RATE_CAT_CD = A.PLAN_RATE_CAT_CD
    AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD

    SELECT    @EXT_PREMIUM_AMT = SUM(B.PREMIUM_AMT)
    FROM      TPOLICYCERTPREMIUM A,
              TPREMLOOKUP B
    WHERE     A.POLICYCERT_NO = @POLICYCERT_NO
    AND       A.END_EFF_DATE = @END_EFF_DATE
    AND       A.RIDER_NO = @RIDER_NO
    AND       A.PRODUCT_CD = @PRODUCT_CD
    AND       B.PLAN_NO = @ASS_PLAN_NO
    AND       B.END_EFF_DATE = @ASS_PLAN_EFF_DATE
    AND       B.PRODUCT_CD = @PRODUCT_CD
    AND       B.PLAN_LAYER_CD = A.PLAN_LAYER_CD
    AND       B.PLAN_RATE_CAT_CD = A.PLAN_RATE_CAT_CD
    AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD    
    
-----------------------------------------------------------

     SELECT    PHOLD_FNAME = @CPFNAME1,
               EXT_PREMIUM_AMT = @EXT_PREMIUM_AMT,
               TOTAL_BENEFIT_AMT = @TOTAL_BENEFIT_AMT, 
               A.POLICYCERT_NO, 
               A.END_EFF_DATE, 
               A.RIDER_NO, 
               A.POLICY_EFF_DATE, 
               A.POL_EXP_DATE, 
               A.PLAN_NO, 
               A.USERID_CD, 
               A.APP_ENTRY_DATE, 
               A.POLICY_HOLDER_NO, 
               A.PHOLD_TITLE_NAME, 
               A.PHOLD_M_INIT_NAME, 
               A.PHOLD_GIVEN_NAME, 
               A.PHOLD_FAMILY_NAME, 
               A.PHOLD_POST_CD, 
               A.PHOLD_STATE_ADDR, 
               A.PHOLD_CITY_ADDR, 
               A.PHOLD_1_ADDR, 
               A.PHOLD_2_ADDR, 
               A.PHOLD_3_ADDR, 
               A.PHOLD_4_ADDR, 
               A.PHOLD_FULLADDR, 
               A.PLAN_NAME, 
               A.PLAN_TYPE, 
               A.DOCUMENT_ISO, 
               A.ISSUING_BRNCH_CD,
               CHI_COMPANY_NAME  = ISS_BRNCH_1_ADDR,
               ENG_COMPANY_NAME  = ISS_BRNCH_NAME,
               COMPANY_ADDRESS   = ISS_BRNCH_2_ADDR, 
               HOTLINE_NO        = ISS_BRCH_PHONE_NO,
               PHONE_NO          = ISS_BRNCH_3_ADDR,
               FAX_NO            = ISS_BRNCH_4_ADDR
     FROM      #TMPOUT1 A,
     		   tissuebranch B
	 WHERE     B.ISSUING_BRNCH_CD = A.ISSUING_BRNCH_CD
END
go
IF OBJECT_ID('dbo.WSM_NB5_MASTER') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_NB5_MASTER >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_NB5_MASTER >>>'
go
GRANT EXECUTE ON dbo.WSM_NB5_MASTER TO userall 
go

print "After"
go
sp_help WSM_NB5_MASTER
go