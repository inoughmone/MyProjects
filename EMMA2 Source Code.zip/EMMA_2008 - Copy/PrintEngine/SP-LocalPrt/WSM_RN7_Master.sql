print "Before"
go
sp_help WSM_RN7_Master
go

IF OBJECT_ID('dbo.WSM_RN7_Master') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_RN7_Master
    IF OBJECT_ID('dbo.WSM_RN7_Master') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_RN7_Master >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_RN7_Master >>>'
END
go
/*
****************************************************************************************************
Title				: WSM_RN7_Master
Author		        : MPHASIS
Date		        : 09/12/2006
Description	        : This stored procedure is used as the main SP for WSM_RN7 - Migrated Renewal Schdeule
Use for			    : 
****************************************************************************************************
*/
CREATE PROCEDURE dbo.WSM_RN7_Master
    @cPolicyCert     	VarChar(14),
    @dEndEffDt			Datetime,
    @iRider          	Smallint,
    @iPrintJob       	Int,
    @BILL_FREQ_CH       CHAR(25)  = "BILL-FREQ-DESC-CH",
    @REF_GROUP_CD       CHAR(6)   = "061000"

AS
BEGIN
    DECLARE
        @cStateCity         VarChar(37),
        @cAddr1				VarChar(186),
        @cAddr2				VarChar(92),
        @cPFName1			VarChar(83),
        @cPFName2			VarChar(45),
        @cIFName1			VarChar(83),
        @cIFName2			VarChar(45)

    SELECT 	a.policycert_no, 
			a.end_eff_date, 
			a.rider_no, 
			a.name_insured_no, 
			a.relation_cd,
			a.nam_ins_title_name, 
			a.nam_ins_minit_name, 
			a.nam_ins_given_name, 
			a.nam_ins_fam_name,
			b.bank_name, 
			b.bill_freq_cd,
			POLICY_EFF_DATE = CASE WHEN C.END_EFF_DATE < C.POLICY_REN_DATE 
                                    THEN DATEADD(YEAR,-1,C.POLICY_REN_DATE)
                                    ELSE C.POLICY_REN_DATE 
                                    END,
            POL_EXP_DATE = CASE WHEN C.END_EFF_DATE < C.POLICY_REN_DATE 
                                    THEN DATEADD(DAY,-1,C.POLICY_REN_DATE)
                                    ELSE DATEADD(DAY,-1,DATEADD(year, 1, C.POLICY_REN_DATE ))
                                    END, 
			c.plan_no, 
			c.userid_cd, 
			c.appl_received_date as app_entry_date, 
			policy_holder_no = Convert(Int, NULL), 
			phold_title_name = Convert(Char(5), ''), 
			phold_m_init_name = ' ',
			phold_given_name = Convert(VarChar(30), ''), 
			phold_family_name = Convert(VarChar(45), ''),
			phold_post_cd = Convert(VarChar(10), ''), 
			phold_state_addr = Convert(VarChar(5), ''), 
			phold_city_addr = Convert(VarChar(30), ''),
			phold_1_addr = Convert(VarChar(45), ''), 
			phold_2_addr = Convert(VarChar(45), ''), 
			phold_3_addr = Convert(VarChar(45), ''),
			phold_4_addr = Convert(VarChar(45), ''), 
			phold_fulladdr = Convert(VarChar(254), ''),
			plan_name = Convert(VarChar(50), ''), 
			plan_type = Convert(Char(1), '0'),
			prm_per_period_amt = Convert(Money, 0), 
			bill_freq_desc = Convert(VarChar(25), ''),
			document_iso = Convert(VarChar(20), '', NULL)
    INTO 	#tmpOut1
    FROM 	tnamedinsured a,
            tpaymentdets b,
            tpolicycertrider c
	WHERE	a.policycert_no = b.policycert_no AND a.end_eff_date = b.end_eff_date
	AND 	a.policycert_no = c.policycert_no AND a.end_eff_date = c.end_eff_date AND a.rider_no = c.rider_no
	AND 	a.policycert_no = @cPolicyCert
	AND 	a.end_eff_date = @dEndEffDt
	AND 	a.rider_no = 0
	AND     a.name_insured_no = 0

    UPDATE 	#tmpOut1
	SET 	a.plan_name = b.plan_name
	FROM 	#tmpOut1 a, tplandets b
	WHERE   a.plan_no = b.plan_no
	AND     b.end_eff_date = (SELECT Max(x.end_eff_date) FROM tplandets x WHERE x.plan_no = a.plan_no)

    --Update policy total monthly premium, policy holder name and address
    UPDATE  #tmpOut1
	SET     a.prm_per_period_amt = b.prm_per_period_amt, 
	        a.policy_holder_no = b.policy_holder_no, 
	        a.phold_title_name = c.phold_title_name,
	        a.phold_m_init_name = c.phold_m_init_name, 
	        a.phold_given_name = c.phold_given_name, 
	        a.phold_family_name = c.phold_family_name,
	        a.phold_post_cd = c.phold_post_cd, 
	        a.phold_state_addr = c.phold_state_addr, 
	        a.phold_city_addr = c.phold_city_addr, 
	        a.phold_1_addr = c.phold_1_addr, 
	        a.phold_2_addr = c.phold_2_addr, 
	        a.phold_3_addr = c.phold_3_addr
	FROM    #tmpOut1 a, tpolicycert b, tpolicycertholder c
    WHERE   a.policycert_no = b.policycert_no
	AND     b.policy_holder_no = c.policy_holder_no 

    -- Address and Names in Chinese form.
    SELECT  @cAddr1 = CASE WHEN phold_1_addr IN ('', NULL) OR phold_2_addr IN ('', NULL)
                        THEN phold_1_addr + phold_2_addr 
                        ELSE phold_1_addr + ' ' + phold_2_addr 
                        END,
        @cAddr2 = CASE WHEN phold_3_addr IN ('', NULL) OR phold_4_addr IN ('', NULL)
                        THEN phold_3_addr + phold_4_addr 
		                ELSE phold_3_addr + ' ' + phold_4_addr 
                        END,
        @cPFName1 = CASE WHEN phold_given_name IN ('', NULL) OR phold_m_init_name IN (' ', NULL)
                        THEN phold_given_name + RTrim(phold_m_init_name) 
	                    ELSE phold_given_name + ' ' + phold_m_init_name 
	                    END,
    	@cIFName1 = CASE WHEN nam_ins_given_name IN ('', NULL) OR nam_ins_minit_name IN (' ', NULL)
                        THEN nam_ins_given_name + RTrim(nam_ins_minit_name) 
    		            ELSE nam_ins_given_name + ' ' + nam_ins_minit_name 
                        END,
	    @cPFName2 = phold_family_name, 
	    @cIFName2 = nam_ins_fam_name
	FROM #tmpOut1


    SELECT @cAddr1 = CASE WHEN @cAddr1 IN ('', NULL) OR @cAddr2 IN ('', NULL)
                        THEN @cAddr1 + @cAddr2 
		                ELSE @cAddr1 + ' ' + @cAddr2 
                        END,
        @cPFName1 = CASE WHEN @cPFName1 IN ('', NULL) OR @cPFName2 IN ('', NULL)
                        THEN @cPFName2 + @cPFName1 
		                ELSE @cPFName2 + ' ' + @cPFName1 
                        END,
        @cIFName1 = CASE WHEN @cIFName1 IN ('', NULL) OR @cIFName2 IN ('', NULL)
                        THEN @cIFName2 + @cIFName1 
		                ELSE @cIFName2 + ' ' + @cIFName1
                        END

    UPDATE #tmpOut1	SET phold_fulladdr = @cAddr1
		
-- ***
    UPDATE #tmpOut1
	SET    a.bill_freq_desc = b.bill_freq_desc
	FROM   #tmpOut1 a, tbillfreqdets b
	WHERE  a.bill_freq_cd = b.bill_freq_cd

    UPDATE #tmpOut1
    SET document_iso = (SELECT a.document_iso 
                        FROM tformletters a, tprintqueue b
                        WHERE a.document_name = b.document_name 
                        AND b.policycert_no = @cPolicyCert 
                        AND b.print_job_no = @iPrintJob
                       )

    UPDATE #tmpOut1
	SET plan_type = CASE WHEN (SELECT Count(DISTINCT name_insured_no) 
                                FROM tnamedinsured x 
                                WHERE x.policycert_no = a.policycert_no 
                                AND x.end_eff_date = a.end_eff_date
                                AND x.rider_no = a.rider_no) > 1 THEN '1' ELSE '0' END
	FROM #tmpOut1 a

    UPDATE  #tmpOut1
    SET     BILL_FREQ_DESC = isnull(LTRIM(RTRIM((SELECT     MAX(B.ELE_VALUE_DESC_TXT)
                                             FROM      TREFTAB b
                                             WHERE     B.REF_GROUP_CD        = @REF_GROUP_CD
                                             AND       B.DATA_ELEMENT_NAME   = @BILL_FREQ_CH
                                             AND       B.DATA_ELEMENT_CODE   = A.BILL_FREQ_CD))),"")
    FROM    #tmpOut1 A


    SELECT 	phold_fname = @cPFName1,
            insured_fname = @cIFName1, 
            #tmpOut1.policycert_no, 
			#tmpOut1.end_eff_date, 
			#tmpOut1.rider_no, 
			#tmpOut1.name_insured_no, 
			#tmpOut1.relation_cd, 
			#tmpOut1.nam_ins_title_name, 
			#tmpOut1.nam_ins_minit_name, 
			#tmpOut1.nam_ins_given_name, 
			#tmpOut1.nam_ins_fam_name, 
			#tmpOut1.bank_name, 
			#tmpOut1.bill_freq_cd, 
			#tmpOut1.policy_eff_date, 
			#tmpOut1.pol_exp_date, 
			#tmpOut1.plan_no, 
			#tmpOut1.userid_cd, 
			#tmpOut1.app_entry_date, 
			#tmpOut1.policy_holder_no, 
			#tmpOut1.phold_title_name, 
			#tmpOut1.phold_m_init_name, 
			#tmpOut1.phold_given_name, 
			#tmpOut1.phold_family_name, 
			#tmpOut1.phold_post_cd, 
			#tmpOut1.phold_state_addr, 
			#tmpOut1.phold_city_addr, 
			#tmpOut1.phold_1_addr, 
			#tmpOut1.phold_2_addr, 
			#tmpOut1.phold_3_addr, 
			#tmpOut1.phold_4_addr, 
			#tmpOut1.phold_fulladdr, 
			#tmpOut1.plan_name, 
			#tmpOut1.plan_type, 
			#tmpOut1.prm_per_period_amt, 
			#tmpOut1.bill_freq_desc, 
			#tmpOut1.document_iso
    FROM #tmpOut1
 
END

go
IF OBJECT_ID('dbo.WSM_RN7_Master') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_RN7_Master >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_RN7_Master >>>'
go
GRANT EXECUTE ON dbo.WSM_RN7_Master TO userall 
go

print "After"
go
sp_help WSM_RN7_Master
go
