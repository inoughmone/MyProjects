print "Before"
go
sp_help HeaderFooterDetails
go

IF OBJECT_ID('dbo.HeaderFooterDetails') IS NOT NULL
BEGIN
DROP PROCEDURE dbo.HeaderFooterDetails
	IF OBJECT_ID('dbo.HeaderFooterDetails') IS NOT NULL
		PRINT '<<<FAILED DROPPING PROCEDURE dbo.HeaderFooterDetails >>>'
	ELSE
		PRINT '<<<DROPPED PROCEDURE dbo.HeaderFooterDetails >>>'
END
GO

/*
Author: Snow Ren
Date: 2006-03-30
Usage: Get HeaderFooterDetails
*/
CREATE PROCEDURE dbo.HeaderFooterDetails

 @ISSUING_BRNCH_CD      varchar(10)

AS

BEGIN

set chained off

select ISS_BRNCH_1_ADDR as CHI_COMPANY_NAME,
       ISS_BRNCH_NAME as ENG_COMPANY_NAME,
       (ISS_BRNCH_CTRY_ADDR +""+ISS_BRCH_CITY_ADDR) as ADDR_LINE_1,
       ISS_BRNCH_2_ADDR as ADDR_LINE_2,
       ISS_BRCH_POST_CD as ADDR_LINE_3,
       ISS_BRNCH_3_ADDR as ADDR_LINE_4,
       ISS_BRNCH_4_ADDR as ADDR_LINE_5,
       ISS_BRCH_PHONE_NO as HOTLINE_NO,
       GM_NAME = ISNULL(( SELECT ELE_VALUE_DESC_TXT
                                  FROM TREFTAB
                                  WHERE  
					data_element_name = 'BRNCH-GM-NAME-CH' 
                                  and 
                                        substring(data_element_code,1,2) = @ISSUING_BRNCH_CD),"N/A")
from 
       	tissuebranch
where 
       ISSUING_BRNCH_CD = @ISSUING_BRNCH_CD
  
END

go
GRANT EXECUTE ON dbo.HeaderFooterDetails TO userall 
go


print "After"
go
sp_help HeaderFooterDetails
go