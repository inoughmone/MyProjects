print "Before"
go
sp_help WSM_NAMEINSURED_MIGRATED
go

IF OBJECT_ID('dbo.WSM_NAMEINSURED_MIGRATED') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_NAMEINSURED_MIGRATED
    IF OBJECT_ID('dbo.WSM_NAMEINSURED_MIGRATED') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_NAMEINSURED_MIGRATED >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_NAMEINSURED_MIGRATED >>>'
END
go
/*
****************************************************************************************************
TITLE				: WSM_NAMEINSURED_MIGRATED
AUTHOR		        : MPHASIS
DATE		        : 09/12/2006
DESCRIPTION	        : THIS STORED PROCEDURE IS USED FOR MIGRATED RENEWAL(Name insured in all rider)
USE FOR			    :
****************************************************************************************************
*/

CREATE PROCEDURE dbo.WSM_NAMEINSURED_MIGRATED
     @CPOLICYCERT   VARCHAR(14),
     @DENDEFFDT	    DATETIME,
     @RELATION_CD   CHAR(20)  = "RELATION-CODE-CH",
     @NO_ID         CHAR(21)  = "DESC-ID-NOT-AVAILABLE",
     @REF_GROUP_CD  CHAR(6)   = "061000"
AS
BEGIN
     SELECT   DISTINCT 
     		  POLICYCERT_NO,
              END_EFF_DATE,
              NAME_INSURED_NO,
              ISNULL(NAM_INS_TITLE_NAME,'') NAM_INS_TITLE_NAME,
              ISNULL(NAM_INS_MINIT_NAME,'') NAM_INS_MINIT_NAME,
              ISNULL(NAM_INS_GIVEN_NAME,'') NAM_INS_GIVEN_NAME,
		      ISNULL(NAM_INS_FAM_NAME,'') NAM_INS_FAM_NAME,
		      RELATION_CD,
		      CASE RELATION_CD
		                WHEN "P"    THEN  1
		                WHEN "S"	THEN  2
		                WHEN "D"    THEN  3
		                WHEN "O"	THEN  4
		                WHEN "T"    THEN  5
		                ELSE 6
		       END AS RELATION_NUM,
		       NAM_INS_BIRTH_DATE,
		       SOCIAL_SEC_NO,
		       RELATIONSHIP = CONVERT(VARCHAR(50), ''),
		       COMMENTS_TEXT		          
     INTO      #TMPOUT1
     FROM      TNAMEDINSURED
     WHERE     POLICYCERT_NO  = @CPOLICYCERT
     AND       END_EFF_DATE   = @DENDEFFDT     

     UPDATE    #TMPOUT1
	 SET       RELATIONSHIP        = B.ELE_VALUE_DESC_TXT
	 FROM      #TMPOUT1 A,
	           TREFTAB B
	 WHERE     A.RELATION_CD       = B.DATA_ELEMENT_CODE
	 AND       B.DATA_ELEMENT_NAME = @RELATION_CD

	 UPDATE    #TMPOUT1
     SET       SOCIAL_SEC_NO  = LTRIM(RTRIM(( SELECT MAX(ELE_VALUE_DESC_TXT)
                                  FROM   TREFTAB
                                  WHERE  REF_GROUP_CD       = @REF_GROUP_CD
                                  AND    DATA_ELEMENT_NAME  = @NO_ID)))
     WHERE     RELATION_CD    = "D"
     AND       (SOCIAL_SEC_NO IS NULL OR SOCIAL_SEC_NO IN (""," "))

     SELECT   DISTINCT
              FULLNAME        = (RTRIM(NAM_INS_FAM_NAME) + ' ' + RTRIM(NAM_INS_GIVEN_NAME) + ' ' + RTRIM(NAM_INS_MINIT_NAME)),
	          RELATION_CD,
	          RELATIONSHIP,
	          BIRTHDATE       = CONVERT(VARCHAR(10), NAM_INS_BIRTH_DATE, 111),
	          ID_NO           = SOCIAL_SEC_NO,
	          NAM_INS_BIRTH_DATE,
	          COMMENTS_TEXT,
	          INSCOUNT        = COUNT(100),
	          NAME_INSURED_NO = MAX(NAME_INSURED_NO) 
     FROM     #TMPOUT1
     ORDER BY RELATION_NUM
     
END

go
IF OBJECT_ID('dbo.WSM_NAMEINSURED_MIGRATED') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_NAMEINSURED_MIGRATED >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_NAMEINSURED_MIGRATED >>>'
go
GRANT EXECUTE ON dbo.WSM_NAMEINSURED_MIGRATED TO userall 
go

print "After"
go
sp_help WSM_NAMEINSURED_MIGRATED
go