print "before image"
go
sp_help WSM_NB3_MASTER
go

IF OBJECT_ID('dbo.WSM_NB3_MASTER') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_NB3_MASTER
    IF OBJECT_ID('dbo.WSM_NB3_MASTER') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_NB3_MASTER >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_NB3_MASTER >>>'
END
go
/*
****************************************************************************************************
TITLE           : WSM_NB3_MASTER
AUTHOR          : Snow
DATE            : 02/09/2006
DESCRIPTION     : THIS STORED PROCEDURE IS USED AS MAIN SP FOR WSM_NB3 - POLICY SCHEDULE - NEW BUSINESS
USE FOR         :
****************************************************************************************************
*/

CREATE PROCEDURE dbo.WSM_NB3_MASTER
     @CPOLICYCERT   VARCHAR(14),
     @DENDEFFDT     DATETIME,
     @IRIDER        SMALLINT,
     @IPRINTJOB     INT,
     @BILL_FREQ_CH  CHAR(25)  = "BILL-FREQ-DESC-CH",
     @REF_GROUP_CD  CHAR(6)   = "061000"
AS
BEGIN
     DECLARE   @CSTATECITY    VARCHAR(37),
               @CADDR1        VARCHAR(186),
               @CADDR2        VARCHAR(92),
               @CPFNAME1      VARCHAR(83),
               @CPFNAME2      VARCHAR(45),
               @CIFNAME1      VARCHAR(83),
               @CIFNAME2      VARCHAR(45)

     -- get named insured ----------
     SELECT    A.POLICYCERT_NO,
               A.END_EFF_DATE,
               A.RIDER_NO,
               A.NAME_INSURED_NO,
               A.RELATION_CD,
               A.NAM_INS_TITLE_NAME,
               A.NAM_INS_MINIT_NAME,
               A.NAM_INS_GIVEN_NAME,
               A.NAM_INS_FAM_NAME,
               B.BANK_NAME,
               B.BILL_FREQ_CD,
               POLICY_EFF_DATE     = POLICY_EFF_DATE,
               POL_EXP_DATE        = CONVERT(DATETIME, CASE
               												WHEN C.POL_EXP_DATE IS NOT NULL THEN C.POL_EXP_DATE
                                                            WHEN C.POLICY_REN_DATE IS NULL THEN NULL
                                                            ELSE
                                                                 DATEADD(DAY, -1, c.POLICY_REN_DATE )
                                                       END),
               C.PLAN_NO,
               C.USERID_CD,
               APP_ENTRY_DATE      = C.APPL_RECEIVED_DATE,
               POLICY_HOLDER_NO    = CONVERT(INT, NULL),
               PHOLD_TITLE_NAME    = CONVERT(CHAR(5), ''),
               PHOLD_M_INIT_NAME   = ' ',
               PHOLD_GIVEN_NAME    = CONVERT(VARCHAR(30), ''),
               PHOLD_FAMILY_NAME   = CONVERT(VARCHAR(45), ''),
               PHOLD_POST_CD       = CONVERT(VARCHAR(10), ''),
               PHOLD_STATE_ADDR    = CONVERT(VARCHAR(5), ''),
               PHOLD_CITY_ADDR     = CONVERT(VARCHAR(30), ''),
               PHOLD_1_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_2_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_3_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_4_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_FULLADDR      = CONVERT(VARCHAR(254), ''),
               PLAN_NAME           = CONVERT(VARCHAR(50), ''),
               PLAN_TYPE           = CONVERT(CHAR(1), '0'),
               PRM_PER_PERIOD_AMT  = CONVERT(MONEY, 0),
               BILL_FREQ_DESC      = CONVERT(VARCHAR(25), ''),
               DOCUMENT_ISO        = CONVERT(VARCHAR(20), '', NULL),
               c.CANCEL_DATE
     INTO      #TMPOUT1
     FROM      TNAMEDINSURED A,
               TPAYMENTDETS B,
               TPOLICYCERTRIDER C
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       C.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       C.END_EFF_DATE      = A.END_EFF_DATE
     AND       C.RIDER_NO          = A.RIDER_NO
     AND       A.POLICYCERT_NO     = @CPOLICYCERT
     AND       A.END_EFF_DATE      = @DENDEFFDT
     AND       A.RIDER_NO          = @IRIDER
     AND       A.NAME_INSURED_NO   = 0

     UPDATE    #TMPOUT1
     SET       PLAN_NAME           = B.PLAN_NAME
     FROM      #TMPOUT1 A,
               TPLANDETS B
     WHERE     A.PLAN_NO           = B.PLAN_NO
     AND       B.END_EFF_DATE      = (  SELECT    MAX(X.END_EFF_DATE)
                                        FROM      TPLANDETS X
                                        WHERE     X.PLAN_NO      = A.PLAN_NO
                                        AND       X.END_EFF_DATE <= B.END_EFF_DATE)

     ------- GET POLICYHOLDER INFORMATION
     UPDATE    #TMPOUT1
     SET       POLICY_HOLDER_NO    = B.POLICY_HOLDER_NO,
               PHOLD_TITLE_NAME    = C.PHOLD_TITLE_NAME,
               PHOLD_M_INIT_NAME   = C.PHOLD_M_INIT_NAME,
               PHOLD_GIVEN_NAME    = C.PHOLD_GIVEN_NAME,
               PHOLD_FAMILY_NAME   = C.PHOLD_FAMILY_NAME,
               PHOLD_POST_CD       = C.PHOLD_POST_CD,
               PHOLD_STATE_ADDR    = C.PHOLD_STATE_ADDR,
               PHOLD_CITY_ADDR     = C.PHOLD_CITY_ADDR,
               PHOLD_1_ADDR        = C.PHOLD_1_ADDR,
               PHOLD_2_ADDR        = C.PHOLD_2_ADDR,
               PHOLD_3_ADDR        = C.PHOLD_3_ADDR
     FROM      #TMPOUT1 A,
               TPOLICYCERT B,
               TPOLICYCERTHOLDER C
     WHERE     A.POLICYCERT_NO     = B.POLICYCERT_NO
     AND       B.POLICY_HOLDER_NO  = C.POLICY_HOLDER_NO


     UPDATE    #TMPOUT1
     SET       PRM_PER_PERIOD_AMT  = SUM(B.PREMIUM_AMT)
     FROM      #TMPOUT1 A,
               TPOLICYCERTPREMIUM B
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO


     SELECT    @CSTATECITY    = CASE
                                   WHEN PHOLD_STATE_ADDR IN ('', NULL) OR PHOLD_CITY_ADDR IN ('', NULL) THEN
                                        PHOLD_STATE_ADDR +  PHOLD_CITY_ADDR
                                   ELSE
                                        PHOLD_STATE_ADDR + ', ' + PHOLD_CITY_ADDR END,
               @CADDR1        = CASE
                                   WHEN PHOLD_1_ADDR IN ('', NULL) OR PHOLD_2_ADDR IN ('', NULL) THEN
                                        PHOLD_1_ADDR + PHOLD_2_ADDR
                                   ELSE
                                        PHOLD_1_ADDR + ', ' + PHOLD_2_ADDR END,
               @CADDR2        = CASE
                                   WHEN PHOLD_3_ADDR IN ('', NULL) OR PHOLD_4_ADDR IN ('', NULL) THEN
                                        PHOLD_3_ADDR + PHOLD_4_ADDR
                                   ELSE
                                        PHOLD_3_ADDR + ', ' + PHOLD_4_ADDR END,
               @CPFNAME1      = CASE
                                   WHEN PHOLD_GIVEN_NAME IN ('', NULL) OR PHOLD_M_INIT_NAME IN (' ', NULL) THEN
                                        PHOLD_GIVEN_NAME + RTRIM(PHOLD_M_INIT_NAME)
                                   ELSE
                                        PHOLD_GIVEN_NAME + ' ' + PHOLD_M_INIT_NAME END,
               @CIFNAME1      = CASE
                                   WHEN NAM_INS_GIVEN_NAME IN ('', NULL) OR NAM_INS_MINIT_NAME IN (' ', NULL) THEN
                                        NAM_INS_GIVEN_NAME + RTRIM(NAM_INS_MINIT_NAME)
                                   ELSE
                                        NAM_INS_GIVEN_NAME + ' ' + NAM_INS_MINIT_NAME END,
               @CPFNAME2      = PHOLD_FAMILY_NAME,
               @CIFNAME2      = NAM_INS_FAM_NAME
     FROM      #TMPOUT1

     SELECT    @CADDR1   = CASE
                              WHEN @CADDR1 IN ('', NULL) OR @CADDR2 IN ('', NULL) THEN
                                   @CADDR1 + @CADDR2
                              ELSE
                                   @CADDR1 + ', ' + @CADDR2 END,
               @CPFNAME1 = CASE
                              WHEN @CPFNAME1 IN ('', NULL) OR @CPFNAME2 IN ('', NULL) THEN
                                   @CPFNAME2 + @CPFNAME1
                              ELSE
                                   @CPFNAME2 + ' ' + @CPFNAME1 END,
               @CIFNAME1 = CASE
                              WHEN @CIFNAME1 IN ('', NULL) OR @CIFNAME2 IN ('', NULL) THEN
                                   @CIFNAME2 + @CIFNAME1
                              ELSE
                                   @CIFNAME2 + ' ' + @CIFNAME1 END

     UPDATE    #TMPOUT1
     SET       PHOLD_FULLADDR = @CADDR1



     UPDATE    #TMPOUT1
     SET       BILL_FREQ_DESC = isnull(LTRIM(RTRIM((SELECT     MAX(B.ELE_VALUE_DESC_TXT)
                                             FROM      TREFTAB b
                                             WHERE     B.REF_GROUP_CD        = @REF_GROUP_CD
                                             AND       B.DATA_ELEMENT_NAME   = @BILL_FREQ_CH
                                             AND       B.DATA_ELEMENT_CODE   = A.BILL_FREQ_CD))),"")
     FROM      #TMPOUT1 A

/*
     UPDATE    #TMPOUT1
     SET       BILL_FREQ_DESC = B.BILL_FREQ_DESC
     FROM      #TMPOUT1 A,
               TBILLFREQDETS B
     WHERE     A.BILL_FREQ_CD = B.BILL_FREQ_CD

*/

     UPDATE    #TMPOUT1
     SET       DOCUMENT_ISO = (    SELECT    A.DOCUMENT_ISO
                                   FROM      TFORMLETTERS A,
                                             TPRINTQUEUE B
                                   WHERE     A.DOCUMENT_NAME     = B.DOCUMENT_NAME
                                   AND       B.POLICYCERT_NO     = @CPOLICYCERT
                                   AND       B.PRINT_JOB_NO      = @IPRINTJOB)

     UPDATE    #TMPOUT1
     SET       PLAN_TYPE = CASE
                              WHEN (    SELECT    COUNT(DISTINCT NAME_INSURED_NO)
                                        FROM      TNAMEDINSURED X
                                        WHERE     X.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       X.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       X.RIDER_NO          = A.RIDER_NO) > 1 THEN '1' ELSE '0' END
     FROM #TMPOUT1 A


     SELECT    PHOLD_FNAME = @CPFNAME1,
               INSURED_FNAME = @CIFNAME1,
               #TMPOUT1.POLICYCERT_NO, #TMPOUT1.END_EFF_DATE, #TMPOUT1.RIDER_NO, #TMPOUT1.NAME_INSURED_NO, #TMPOUT1.RELATION_CD, #TMPOUT1.NAM_INS_TITLE_NAME, #TMPOUT1.NAM_INS_MINIT_NAME, #TMPOUT1.NAM_INS_GIVEN_NAME, #TMPOUT1.NAM_INS_FAM_NAME, #TMPOUT1.BANK_NAME, #TMPOUT1.BILL_FREQ_CD, #TMPOUT1.POLICY_EFF_DATE, #TMPOUT1.POL_EXP_DATE, #TMPOUT1.PLAN_NO, #TMPOUT1.USERID_CD, #TMPOUT1.APP_ENTRY_DATE, #TMPOUT1.POLICY_HOLDER_NO, #TMPOUT1.PHOLD_TITLE_NAME, #TMPOUT1.PHOLD_M_INIT_NAME, #TMPOUT1.PHOLD_GIVEN_NAME, #TMPOUT1.PHOLD_FAMILY_NAME, #TMPOUT1.PHOLD_POST_CD, #TMPOUT1.PHOLD_STATE_ADDR, #TMPOUT1.PHOLD_CITY_ADDR, #TMPOUT1.PHOLD_1_ADDR, #TMPOUT1.PHOLD_2_ADDR, #TMPOUT1.PHOLD_3_ADDR, #TMPOUT1.PHOLD_4_ADDR, #TMPOUT1.PHOLD_FULLADDR, #TMPOUT1.PLAN_NAME, #TMPOUT1.PLAN_TYPE, #TMPOUT1.PRM_PER_PERIOD_AMT, #TMPOUT1.BILL_FREQ_DESC, #TMPOUT1.DOCUMENT_ISO, #TMPOUT1.CANCEL_DATE
     FROM      #TMPOUT1

END

go
IF OBJECT_ID('dbo.WSM_NB3_MASTER') IS NOT NULL
		GRANT EXECUTE ON dbo.WSM_NB3_MASTER TO userall
    PRINT '<<< CREATED PROCEDURE dbo.WSM_NB3_MASTER >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_NB3_MASTER >>>'
go


print "after image"
go
sp_help WSM_NB3_MASTER
go
