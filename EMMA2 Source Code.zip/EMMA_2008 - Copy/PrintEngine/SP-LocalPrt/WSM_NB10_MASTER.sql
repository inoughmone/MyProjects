print "Before"
go
sp_help WSM_NB10_MASTER
go

IF OBJECT_ID('dbo.WSM_NB10_MASTER') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_NB10_MASTER
    IF OBJECT_ID('dbo.WSM_NB10_MASTER') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_NB10_MASTER >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_NB10_MASTER >>>'
END
go

/*
****************************************************************************************************
TITLE           : WSM_NB10_MASTER
AUTHOR          : MPHASIS
DATE            : 08/29/2006
DESCRIPTION     : THIS STORED PROCEDURE IS USED AS MAIN SP FOR WSM_NB10 - POLICY SCHEDULE - NEW BUSINESS
									Add field "MaxPeriods"
USE FOR         :
****************************************************************************************************
*/

CREATE PROCEDURE dbo.WSM_NB10_MASTER
     @CPOLICYCERT   VARCHAR(14),
     @DENDEFFDT     DATETIME,
     @IRIDER        SMALLINT,
     @IPRINTJOB     INT,
     @BILL_FREQ_CH  CHAR(25)  = "BILL-FREQ-DESC-CH",
     @REF_GROUP_CD  CHAR(6)   = "061000"
AS
BEGIN
     DECLARE   @CSTATECITY    VARCHAR(37),
               @CADDR1        VARCHAR(186),
               @CADDR2        VARCHAR(92),
               @CPFNAME1      VARCHAR(83),
               @CPFNAME2      VARCHAR(45),
               @CIFNAME1      VARCHAR(83),
               @CIFNAME2      VARCHAR(45)

     -- get named insured ----------
     SELECT    A.POLICYCERT_NO,
               A.END_EFF_DATE,
               A.RIDER_NO,
               A.NAME_INSURED_NO,
               A.RELATION_CD,
               A.NAM_INS_TITLE_NAME,
               A.NAM_INS_MINIT_NAME,
               A.NAM_INS_GIVEN_NAME,
               A.NAM_INS_FAM_NAME,
               B.BANK_NAME,
               B.BILL_FREQ_CD,
               C.POLICY_EFF_DATE,
               POL_EXP_DATE        = CONVERT(DATETIME, CASE
                                                            WHEN C.POLICY_REN_DATE IS NULL THEN NULL
                                                            ELSE
                                                                 DATEADD(DAY, -1, c.POLICY_REN_DATE )
                                                       END),
               C.PLAN_NO,
               C.USERID_CD,
               APP_ENTRY_DATE      = C.APPL_RECEIVED_DATE,
               POLICY_HOLDER_NO    = CONVERT(INT, NULL),
               PHOLD_TITLE_NAME    = CONVERT(CHAR(5), ''),
               PHOLD_M_INIT_NAME   = ' ',
               PHOLD_GIVEN_NAME    = CONVERT(VARCHAR(30), ''),
               PHOLD_FAMILY_NAME   = CONVERT(VARCHAR(45), ''),
               PHOLD_POST_CD       = CONVERT(VARCHAR(10), ''),
               PHOLD_STATE_ADDR    = CONVERT(VARCHAR(5), ''),
               PHOLD_CITY_ADDR     = CONVERT(VARCHAR(30), ''),
               PHOLD_1_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_2_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_3_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_4_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_FULLADDR      = CONVERT(VARCHAR(254), ''),
               PLAN_NAME           = CONVERT(VARCHAR(50), ''),
               PLAN_TYPE           = CONVERT(CHAR(1), '0'),
               PLAN_CLASS          = CONVERT(CHAR(1), '0'),
               PRM_PER_PERIOD_AMT  = CONVERT(MONEY, 0),
               BILL_FREQ_DESC      = CONVERT(VARCHAR(25), ''),
               DOCUMENT_ISO        = CONVERT(VARCHAR(20), '', NULL),
               c.CANCEL_DATE,
               MASTER_POLICY_NO    = CONVERT(VARCHAR(14),'', NULL),
               MEMBERSHIP_NO       = CONVERT(VARCHAR(20),'', NULL),
               MaxPeriods          = CONVERT(int, 0),
               C.ISSUING_BRNCH_CD
     INTO      #TMPOUT1
     FROM      TNAMEDINSURED A,
               TPAYMENTDETS B,
               TPOLICYCERTRIDER C
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       C.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       C.END_EFF_DATE      = A.END_EFF_DATE
     AND       C.RIDER_NO          = A.RIDER_NO
     AND       A.POLICYCERT_NO     = @CPOLICYCERT
     AND       A.END_EFF_DATE      = @DENDEFFDT
     AND       A.RIDER_NO          = @IRIDER
     AND       A.NAME_INSURED_NO   = 0

     UPDATE    #TMPOUT1
     SET       PLAN_NAME           = RTRIM(B.PLAN_NAME),
               MASTER_POLICY_NO    = B.MASTER_POLICY_NO
     FROM      #TMPOUT1 A,
               TPLANDETS B
     WHERE     A.PLAN_NO           = B.PLAN_NO
     AND       B.END_EFF_DATE      = (  SELECT    MAX(X.END_EFF_DATE)
                                        FROM      TPLANDETS X
                                        WHERE     X.PLAN_NO      = A.PLAN_NO)
                                        
     UPDATE    #TMPOUT1
     SET       MaxPeriods = B.MAX_WEEKS_CNT
     FROM      #TMPOUT1 A,
               TPLANPRODUCT B
     WHERE     A.PLAN_NO = B.PLAN_NO
     AND       B.END_EFF_DATE = (  SELECT    MAX(X.END_EFF_DATE)
                                   FROM      TPLANDETS X
                                   WHERE     X.PLAN_NO      = A.PLAN_NO)
     AND       B.RATED_ITEM_FG = 'Y'
     AND       B.SCHED_SECTION_CD = '1'
                                        
     UPDATE    #TMPOUT1
     SET       MEMBERSHIP_NO = B.MEMBERSHIP_NO
     FROM      #TMPOUT1 A,  TPOLICYCERT B
     WHERE     A.POLICYCERT_NO  = B.POLICYCERT_NO

     ------- GET POLICYHOLDER INFORMATION
     UPDATE    #TMPOUT1
     SET       POLICY_HOLDER_NO    = B.POLICY_HOLDER_NO,
               PHOLD_TITLE_NAME    = C.PHOLD_TITLE_NAME,
               PHOLD_M_INIT_NAME   = C.PHOLD_M_INIT_NAME,
               PHOLD_GIVEN_NAME    = C.PHOLD_GIVEN_NAME,
               PHOLD_FAMILY_NAME   = C.PHOLD_FAMILY_NAME,
               PHOLD_POST_CD       = C.PHOLD_POST_CD,
               PHOLD_STATE_ADDR    = C.PHOLD_STATE_ADDR,
               PHOLD_CITY_ADDR     = C.PHOLD_CITY_ADDR,
               PHOLD_1_ADDR        = C.PHOLD_1_ADDR,
               PHOLD_2_ADDR        = C.PHOLD_2_ADDR,
               PHOLD_3_ADDR        = C.PHOLD_3_ADDR
     FROM      #TMPOUT1 A,
               TPOLICYCERT B,
               TPOLICYCERTHOLDER C
     WHERE     A.POLICYCERT_NO     = B.POLICYCERT_NO
     AND       B.POLICY_HOLDER_NO  = C.POLICY_HOLDER_NO


     UPDATE    #TMPOUT1
     SET       PRM_PER_PERIOD_AMT  = SUM(B.PREMIUM_AMT)
     FROM      #TMPOUT1 A,
               TPOLICYCERTPREMIUM B
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO


     SELECT    @CSTATECITY    = CASE
                                   WHEN PHOLD_STATE_ADDR IN ('', NULL) OR PHOLD_CITY_ADDR IN ('', NULL) THEN
                                        PHOLD_STATE_ADDR +  PHOLD_CITY_ADDR
                                   ELSE
                                        PHOLD_STATE_ADDR + ', ' + PHOLD_CITY_ADDR END,
               @CADDR1        = CASE
                                   WHEN PHOLD_1_ADDR IN ('', NULL) OR PHOLD_2_ADDR IN ('', NULL) THEN
                                        PHOLD_1_ADDR + PHOLD_2_ADDR
                                   ELSE
                                        PHOLD_1_ADDR + ', ' + PHOLD_2_ADDR END,
               @CADDR2        = CASE
                                   WHEN PHOLD_3_ADDR IN ('', NULL) OR PHOLD_4_ADDR IN ('', NULL) THEN
                                        PHOLD_3_ADDR + PHOLD_4_ADDR
                                   ELSE
                                        PHOLD_3_ADDR + ', ' + PHOLD_4_ADDR END,
               @CPFNAME1      = CASE
                                   WHEN PHOLD_GIVEN_NAME IN ('', NULL) OR PHOLD_M_INIT_NAME IN (' ', NULL) THEN
                                        PHOLD_GIVEN_NAME + RTRIM(PHOLD_M_INIT_NAME)
                                   ELSE
                                        PHOLD_GIVEN_NAME + ' ' + PHOLD_M_INIT_NAME END,
               @CIFNAME1      = CASE
                                   WHEN NAM_INS_GIVEN_NAME IN ('', NULL) OR NAM_INS_MINIT_NAME IN (' ', NULL) THEN
                                        NAM_INS_GIVEN_NAME + RTRIM(NAM_INS_MINIT_NAME)
                                   ELSE
                                        NAM_INS_GIVEN_NAME + ' ' + NAM_INS_MINIT_NAME END,
               @CPFNAME2      = PHOLD_FAMILY_NAME,
               @CIFNAME2      = NAM_INS_FAM_NAME
     FROM      #TMPOUT1

     SELECT    @CADDR1   = CASE
                              WHEN @CADDR1 IN ('', NULL) OR @CADDR2 IN ('', NULL) THEN
                                   @CADDR1 + @CADDR2
                              ELSE
                                   @CADDR1 + ', ' + @CADDR2 END,
               @CPFNAME1 = CASE
                              WHEN @CPFNAME1 IN ('', NULL) OR @CPFNAME2 IN ('', NULL) THEN
                                   @CPFNAME2 + @CPFNAME1
                              ELSE
                                   @CPFNAME2 + ' ' + @CPFNAME1 END,
               @CIFNAME1 = CASE
                              WHEN @CIFNAME1 IN ('', NULL) OR @CIFNAME2 IN ('', NULL) THEN
                                   @CIFNAME2 + @CIFNAME1
                              ELSE
                                   @CIFNAME2 + ' ' + @CIFNAME1 END

     UPDATE    #TMPOUT1
     SET       PHOLD_FULLADDR = @CADDR1



     UPDATE    #TMPOUT1
     SET       BILL_FREQ_DESC = isnull(LTRIM(RTRIM((SELECT     MAX(B.ELE_VALUE_DESC_TXT)
                                             FROM      TREFTAB b
                                             WHERE     B.REF_GROUP_CD        = @REF_GROUP_CD
                                             AND       B.DATA_ELEMENT_NAME   = @BILL_FREQ_CH
                                             AND       B.DATA_ELEMENT_CODE   = A.BILL_FREQ_CD))),"")
     FROM      #TMPOUT1 A

/*
     UPDATE    #TMPOUT1
     SET       BILL_FREQ_DESC = B.BILL_FREQ_DESC
     FROM      #TMPOUT1 A,
               TBILLFREQDETS B
     WHERE     A.BILL_FREQ_CD = B.BILL_FREQ_CD

*/

     UPDATE    #TMPOUT1
     SET       DOCUMENT_ISO = (    SELECT    A.DOCUMENT_ISO
                                   FROM      TFORMLETTERS A,
                                             TPRINTQUEUE B
                                   WHERE     A.DOCUMENT_NAME     = B.DOCUMENT_NAME
                                   AND       B.POLICYCERT_NO     = @CPOLICYCERT
                                   AND       B.PRINT_JOB_NO      = @IPRINTJOB)

     UPDATE    #TMPOUT1
     SET       PLAN_TYPE = (    SELECT  CONVERT(VARCHAR, COUNT(DISTINCT NAME_INSURED_NO))
                                        FROM      TNAMEDINSURED X
                                        WHERE     X.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       X.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       X.RIDER_NO          = A.RIDER_NO)
     FROM #TMPOUT1 A
     
     UPDATE    #TMPOUT1
     SET       PLAN_CLASS = CASE
                              WHEN (    SELECT    DISTINCT X.SORT_BAND_NO
                                        FROM      TPREMLOOKUP X, TPOLICYCERTPREMIUM P
                                        WHERE     X.PLAN_NO           = A.PLAN_NO
                                        AND       X.END_EFF_DATE      = (SELECT MAX(L.END_EFF_DATE) FROM TPREMLOOKUP L 
                                                                         WHERE L.PLAN_NO = X.PLAN_NO
                                                                         AND L.PRODUCT_CD = X.PRODUCT_CD
                                                                         AND L.PLAN_LAYER_CD = X.PLAN_LAYER_CD
                                                                         AND L.PLAN_RATE_CAT_CD = X.PLAN_RATE_CAT_CD
                                                                         AND L.PLAN_RATE_BAND_CD = X.PLAN_RATE_BAND_CD
                                                                         AND L.END_EFF_DATE <= X.END_EFF_DATE)                                   
                                        AND       X.PRODUCT_CD = P.PRODUCT_CD
                                        AND       X.PLAN_LAYER_CD = P.PLAN_LAYER_CD
                                        AND       X.PLAN_RATE_CAT_CD  = P.PLAN_RATE_CAT_CD
                                        AND       X.PLAN_RATE_BAND_CD = P.PLAN_RATE_BAND_CD
                                        AND       P.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       P.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       P.RIDER_NO          = A.RIDER_NO
                                        AND       P.NAME_INSURED_NO   = 0     ) > 1 THEN '1'                                                                                                                                                              
                              ELSE '0' END
     FROM #TMPOUT1 A


     SELECT    PHOLD_FNAME = @CPFNAME1,
               INSURED_FNAME = @CIFNAME1,
               A.POLICYCERT_NO, 
               A.END_EFF_DATE, 
               A.RIDER_NO, 
               A.NAME_INSURED_NO, 
               A.RELATION_CD, 
               A.NAM_INS_TITLE_NAME, 
               A.NAM_INS_MINIT_NAME, 
               A.NAM_INS_GIVEN_NAME, 
               A.NAM_INS_FAM_NAME, 
               A.BANK_NAME, 
               A.BILL_FREQ_CD, 
               A.POLICY_EFF_DATE, 
               A.POL_EXP_DATE, 
               A.PLAN_NO,
               A.USERID_CD, 
               A.APP_ENTRY_DATE,
               A.POLICY_HOLDER_NO, 
               A.PHOLD_TITLE_NAME, 
               A.PHOLD_M_INIT_NAME,
               A.PHOLD_GIVEN_NAME, 
               A.PHOLD_FAMILY_NAME, 
               A.PHOLD_POST_CD, 
               A.PHOLD_STATE_ADDR, 
               A.PHOLD_CITY_ADDR, 
               A.PHOLD_1_ADDR,                
               A.PHOLD_2_ADDR, 
               A.PHOLD_3_ADDR, 
               A.PHOLD_4_ADDR, 
               A.PHOLD_FULLADDR, 
               A.PLAN_NAME, 
               A.PLAN_TYPE,
               A.PLAN_CLASS, 
               A.PRM_PER_PERIOD_AMT, 
               A.BILL_FREQ_DESC, 
               A.DOCUMENT_ISO, 
               A.CANCEL_DATE,
               A.MASTER_POLICY_NO,
               A.MEMBERSHIP_NO,
               A.MaxPeriods,
               A.ISSUING_BRNCH_CD,
               CHI_COMPANY_NAME  = B.ISS_BRNCH_1_ADDR,
               ENG_COMPANY_NAME  = B.ISS_BRNCH_NAME,
               COMPANY_ADDRESS   = B.ISS_BRNCH_2_ADDR, 
               HOTLINE_NO        = B.ISS_BRCH_PHONE_NO,
               PHONE_NO          = B.ISS_BRNCH_3_ADDR,
               FAX_NO            = B.ISS_BRNCH_4_ADDR
     FROM      #TMPOUT1 A, tissuebranch B
     WHERE     B.ISSUING_BRNCH_CD = A.ISSUING_BRNCH_CD
     
END

go
IF OBJECT_ID('dbo.WSM_NB10_MASTER') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_NB10_MASTER >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_NB10_MASTER >>>'
go
GRANT EXECUTE ON dbo.WSM_NB10_MASTER TO userall 
go

print "After"
go
sp_help WSM_NB10_MASTER
go
