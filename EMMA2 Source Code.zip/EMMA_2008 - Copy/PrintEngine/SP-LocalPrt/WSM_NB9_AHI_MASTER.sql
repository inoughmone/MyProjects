print "Before"
go
sp_help WSM_NB9_AHI_MASTER
go

IF OBJECT_ID('dbo.WSM_NB9_AHI_MASTER') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_NB9_AHI_MASTER
    IF OBJECT_ID('dbo.WSM_NB9_AHI_MASTER') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_NB9_AHI_MASTER >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_NB9_AHI_MASTER >>>'
END
go

/*
****************************************************************************************************
TITLE           : WSM_NB9_AHI_MASTER
AUTHOR          : MPHASIS
DATE            : 11/08/2006
DESCRIPTION     : THIS STORED PROCEDURE IS USED AS MAIN SP FOR WSM_NB9_AHI 
                  - POLICY SCHEDULE - ADDON BUSINESS

USE FOR         :
****************************************************************************************************
*/

CREATE PROCEDURE dbo.WSM_NB9_AHI_MASTER
     @POLICYCERT_NO   VARCHAR(14),
     @END_EFF_DATE     DATETIME,
     @RIDER_NO        SMALLINT,
     @IPRINTJOB     INT,
     @BILL_FREQ_CH  CHAR(25)  = "BILL-FREQ-DESC-CH",
     @REF_GROUP_CD  CHAR(6)   = "061000"
AS
BEGIN
     DECLARE   @CSTATECITY      VARCHAR(37),
               @CADDR1          VARCHAR(186),
               @CADDR2          VARCHAR(92),
               @CPFNAME1        VARCHAR(83),
               @CPFNAME2        VARCHAR(45),
               @CIFNAME1        VARCHAR(83),
               @CIFNAME2        VARCHAR(45)

     -- get named insured ----------
     SELECT    A.POLICYCERT_NO,
               A.END_EFF_DATE,
               A.RIDER_NO,
               B.BILL_FREQ_CD,
               A.POLICY_EFF_DATE,
               POL_EXP_DATE        = CONVERT(DATETIME, CASE
                                                            WHEN A.POLICY_REN_DATE IS NULL THEN NULL
                                                            ELSE
                                                                 DATEADD(DAY, -1, A.POLICY_REN_DATE )
                                                       END),
               A.PLAN_NO,
               A.USERID_CD,
               APP_ENTRY_DATE      = A.APPL_RECEIVED_DATE,
               POLICY_HOLDER_NO    = CONVERT(INT, NULL),
               PHOLD_TITLE_NAME    = CONVERT(CHAR(5), ''),
               PHOLD_M_INIT_NAME   = ' ',
               PHOLD_GIVEN_NAME    = CONVERT(VARCHAR(30), ''),
               PHOLD_FAMILY_NAME   = CONVERT(VARCHAR(45), ''),
               PHOLD_POST_CD       = CONVERT(VARCHAR(10), ''),
               PHOLD_STATE_ADDR    = CONVERT(VARCHAR(5), ''),
               PHOLD_CITY_ADDR     = CONVERT(VARCHAR(30), ''),
               PHOLD_1_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_2_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_3_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_4_ADDR        = CONVERT(VARCHAR(45), ''),
               PHOLD_FULLADDR      = CONVERT(VARCHAR(254), ''),
               PLAN_NAME           = CONVERT(VARCHAR(50), ''),
               PLAN_TYPE           = CONVERT(CHAR(1), '0'),
               PLAN_CLASS          = CONVERT(CHAR(1), '0'),
               PRM_PER_PERIOD_AMT  = CONVERT(MONEY, 0),
               BILL_FREQ_DESC      = CONVERT(VARCHAR(25), ''),
               DOCUMENT_ISO        = CONVERT(VARCHAR(20), '', NULL),
               MASTER_POLICY_NO    = CONVERT(VARCHAR(14),'',NULL),
               MEMBERSHIP_NO       = CONVERT(VARCHAR(20),'', NULL),
               MaxPeriods          = CONVERT(int, 0),
               A.ISSUING_BRNCH_CD
     INTO      #TMPOUT1
     FROM      TPOLICYCERTRIDER A,
               TPAYMENTDETS B
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.END_EFF_DATE      = @END_EFF_DATE
     AND       A.RIDER_NO          = @RIDER_NO


     UPDATE    #TMPOUT1
     SET       PLAN_NAME          = RTRIM(B.PLAN_NAME),
               MASTER_POLICY_NO  = B.MASTER_POLICY_NO
     FROM      #TMPOUT1 A,
               TPLANDETS B
     WHERE     A.PLAN_NO           = B.PLAN_NO
     AND       B.END_EFF_DATE      = (  SELECT    MAX(X.END_EFF_DATE)
                                        FROM      TPLANDETS X
                                        WHERE     X.PLAN_NO      = A.PLAN_NO)
     
--Get the maxperiod. 
--Get the maxperiod from the product code is like 'AHI' not 'AHICU'.
--if no data, Get the maxperiod from the product code is like 'AHICU'.
--if no data, the maxperiod is 0. 
     UPDATE    #TMPOUT1
     SET       MaxPeriods = B.MAX_WEEKS_CNT
     FROM      #TMPOUT1 A,
               TPLANPRODUCT B
     WHERE     A.PLAN_NO = B.PLAN_NO
     AND       B.END_EFF_DATE = (  SELECT    MAX(X.END_EFF_DATE)
                                   FROM      TPLANDETS X
                                   WHERE     X.PLAN_NO      = A.PLAN_NO)
     AND       SUBSTRING(B.PRODUCT_CD,1,5) = 'AHICU'
     AND       B.COVERAGE_CD = 'AHI'

     UPDATE    #TMPOUT1
     SET       MaxPeriods = B.MAX_WEEKS_CNT
     FROM      #TMPOUT1 A,
               TPLANPRODUCT B
     WHERE     A.PLAN_NO = B.PLAN_NO
     AND       B.END_EFF_DATE = (  SELECT    MAX(X.END_EFF_DATE)
                                   FROM      TPLANDETS X
                                   WHERE     X.PLAN_NO      = A.PLAN_NO)
     AND       SUBSTRING(B.PRODUCT_CD,1,3) = 'AHI'
     AND       SUBSTRING(B.PRODUCT_CD,1,5) <> 'AHICU'
     AND       B.COVERAGE_CD = 'AHI'
                                             
     UPDATE    #TMPOUT1
     SET       MEMBERSHIP_NO = B.MEMBERSHIP_NO
     FROM      #TMPOUT1 A,  TPOLICYCERT B
     WHERE     A.POLICYCERT_NO  = B.POLICYCERT_NO

     ------- GET POLICYHOLDER INFORMATION
     UPDATE    #TMPOUT1
     SET       POLICY_HOLDER_NO    = B.POLICY_HOLDER_NO,
               PHOLD_TITLE_NAME    = C.PHOLD_TITLE_NAME,
               PHOLD_M_INIT_NAME   = C.PHOLD_M_INIT_NAME,
               PHOLD_GIVEN_NAME    = C.PHOLD_GIVEN_NAME,
               PHOLD_FAMILY_NAME   = C.PHOLD_FAMILY_NAME,
               PHOLD_POST_CD       = C.PHOLD_POST_CD,
               PHOLD_STATE_ADDR    = C.PHOLD_STATE_ADDR,
               PHOLD_CITY_ADDR     = C.PHOLD_CITY_ADDR,
               PHOLD_1_ADDR        = C.PHOLD_1_ADDR,
               PHOLD_2_ADDR        = C.PHOLD_2_ADDR,
               PHOLD_3_ADDR        = C.PHOLD_3_ADDR,
			   PHOLD_4_ADDR        = C.PHOLD_4_ADDR
     FROM      #TMPOUT1 A,
               TPOLICYCERT B,
               TPOLICYCERTHOLDER C
     WHERE     A.POLICYCERT_NO     = B.POLICYCERT_NO
     AND       B.POLICY_HOLDER_NO  = C.POLICY_HOLDER_NO
     
     UPDATE    #TMPOUT1
     SET       A.PRM_PER_PERIOD_AMT  = B.PRM_PER_PERIOD_AMT
     FROM      #TMPOUT1 A,
               TPOLICYCERT B
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     
     UPDATE    #TMPOUT1
     SET       BILL_FREQ_DESC = isnull(LTRIM(RTRIM((SELECT     MAX(B.ELE_VALUE_DESC_TXT)
                                             FROM      TREFTAB b
                                             WHERE     B.REF_GROUP_CD        = @REF_GROUP_CD
                                             AND       B.DATA_ELEMENT_NAME   = @BILL_FREQ_CH
                                             AND       B.DATA_ELEMENT_CODE   = A.BILL_FREQ_CD))),"")
     FROM      #TMPOUT1 A


     SELECT    @CSTATECITY    = CASE
                                   WHEN PHOLD_STATE_ADDR IN ('', NULL) OR PHOLD_CITY_ADDR IN ('', NULL) THEN
                                        PHOLD_STATE_ADDR +  PHOLD_CITY_ADDR
                                   ELSE
                                        PHOLD_STATE_ADDR + ', ' + PHOLD_CITY_ADDR END,
               @CADDR1        = CASE
                                   WHEN PHOLD_1_ADDR IN ('', NULL) OR PHOLD_2_ADDR IN ('', NULL) THEN
                                        PHOLD_1_ADDR + PHOLD_2_ADDR
                                   ELSE
                                        PHOLD_1_ADDR + ', ' + PHOLD_2_ADDR END,
               @CADDR2        = CASE
                                   WHEN PHOLD_3_ADDR IN ('', NULL) OR PHOLD_4_ADDR IN ('', NULL) THEN
                                        PHOLD_3_ADDR + PHOLD_4_ADDR
                                   ELSE
                                        PHOLD_3_ADDR + ', ' + PHOLD_4_ADDR END,
               @CPFNAME1      = CASE
                                   WHEN PHOLD_GIVEN_NAME IN ('', NULL) OR PHOLD_M_INIT_NAME IN (' ', NULL) THEN
                                        PHOLD_GIVEN_NAME + RTRIM(PHOLD_M_INIT_NAME)
                                   ELSE
                                        PHOLD_GIVEN_NAME + ' ' + PHOLD_M_INIT_NAME END,
               @CPFNAME2      = PHOLD_FAMILY_NAME
     FROM      #TMPOUT1

     SELECT    @CADDR1   = CASE
                              WHEN @CADDR1 IN ('', NULL) OR @CADDR2 IN ('', NULL) THEN
                                   @CADDR1 + @CADDR2
                              ELSE
                                   @CADDR1 + ','++ CHAR(13)+ CHAR(10) + + @CADDR2 END,
               @CPFNAME1 = CASE
                              WHEN @CPFNAME1 IN ('', NULL) OR @CPFNAME2 IN ('', NULL) THEN
                                   @CPFNAME2 + @CPFNAME1
                              ELSE
                                   @CPFNAME2 + ' ' + @CPFNAME1 END

     UPDATE    #TMPOUT1
     SET       PHOLD_FULLADDR = @CADDR1


     UPDATE    #TMPOUT1
     SET       DOCUMENT_ISO = (    SELECT    A.DOCUMENT_ISO
                                   FROM      TFORMLETTERS A,
                                             TPRINTQUEUE B
                                   WHERE     A.DOCUMENT_NAME     = B.DOCUMENT_NAME
                                   AND       B.POLICYCERT_NO     = @POLICYCERT_NO
                                   AND       B.PRINT_JOB_NO      = @IPRINTJOB)

     UPDATE    #TMPOUT1
     SET       PLAN_TYPE = (    SELECT  CONVERT(VARCHAR, COUNT(DISTINCT NAME_INSURED_NO))
                                        FROM      TNAMEDINSURED X
                                        WHERE     X.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       X.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       X.RIDER_NO          = A.RIDER_NO)
     FROM      #TMPOUT1 A
     
     
     SELECT    PHOLD_FNAME = @CPFNAME1,
               A.PRM_PER_PERIOD_AMT,
               A.BILL_FREQ_DESC,
               A.POLICYCERT_NO, 
               A.END_EFF_DATE, 
               A.RIDER_NO, 
               A.POLICY_EFF_DATE, 
               A.POL_EXP_DATE, 
               A.PLAN_NO, 
               A.USERID_CD, 
               A.APP_ENTRY_DATE, 
               A.POLICY_HOLDER_NO, 
               A.PHOLD_TITLE_NAME, 
               A.PHOLD_M_INIT_NAME, 
               A.PHOLD_GIVEN_NAME, 
               A.PHOLD_FAMILY_NAME, 
               A.PHOLD_POST_CD, 
               A.PHOLD_STATE_ADDR, 
               A.PHOLD_CITY_ADDR, 
               A.PHOLD_1_ADDR, 
               A.PHOLD_2_ADDR, 
               A.PHOLD_3_ADDR, 
               A.PHOLD_4_ADDR, 
               A.PHOLD_FULLADDR, 
               A.PLAN_NAME, 
               A.PLAN_TYPE,
               A.PLAN_CLASS, 
               A.DOCUMENT_ISO,
               A.MASTER_POLICY_NO,
               A.MEMBERSHIP_NO,
               A.MaxPeriods,
               A.ISSUING_BRNCH_CD,
               CHI_COMPANY_NAME  = B.ISS_BRNCH_1_ADDR,
               ENG_COMPANY_NAME  = B.ISS_BRNCH_NAME,
               COMPANY_ADDRESS   = B.ISS_BRNCH_2_ADDR, 
               HOTLINE_NO        = B.ISS_BRCH_PHONE_NO,
               PHONE_NO          = B.ISS_BRNCH_3_ADDR,
               FAX_NO            = B.ISS_BRNCH_4_ADDR
     FROM      #TMPOUT1 A, tissuebranch B
     WHERE     B.ISSUING_BRNCH_CD = A.ISSUING_BRNCH_CD
     
END

go
IF OBJECT_ID('dbo.WSM_NB9_AHI_MASTER') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_NB9_AHI_MASTER >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_NB9_AHI_MASTER >>>'
go
GRANT EXECUTE ON dbo.WSM_NB9_AHI_MASTER TO userall 
go

print "After"
go
sp_help WSM_NB9_AHI_MASTER
go
