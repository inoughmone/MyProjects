print "Before"
go
sp_help WSM_BENEFITS_CORE
go

IF OBJECT_ID('dbo.WSM_BENEFITS_CORE') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_BENEFITS_CORE
    IF OBJECT_ID('dbo.WSM_BENEFITS_CORE') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_BENEFITS_CORE >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_BENEFITS_CORE >>>'
END
go
/*
****************************************************************************************************
TITLE				: WSM_BENEFITS_CORE
AUTHOR		        : MPHASIS
DATE		        : 09/12/2006
DESCRIPTION	        : THIS STORED PROCEDURE IS USED FOR MIGRATED RENEWAL(Add benefit field for Other)
USE FOR			    :
****************************************************************************************************
*/
CREATE PROCEDURE dbo.WSM_BENEFITS_CORE
     @POLICYCERT_NO      VARCHAR(14),     
     @dEndEffDt			 Datetime,     
     @REF_GROUP_CD       CHAR(6)   = "061000",
     @BENEFIT_UNIT       CHAR(32)  = "BENEFIT-TIME-UNIT"
AS
BEGIN

     SELECT    C.POLICYCERT_NO,
               C.END_EFF_DATE,
               C.RIDER_NO,
               C.NAME_INSURED_NO,
               A.PLAN_NO,
               PLAN_EFF_DATE       = A.END_EFF_DATE,
               A.PRODUCT_CD,
               B.PRODUCT_NAME,
               C.RELATION_CD,
               BENEFIT_AMT         = CONVERT(MONEY,0),
               PLAN_LAYER_CD       = SPACE(10),
               PLAN_RATE_CAT_CD    = SPACE(10),
               PLAN_RATE_BAND_CD   = SPACE(10),
               RATED_INSURED_FG    = CONVERT(INT,0),
               PUB_RATE_INT_CD     = D.BILL_FREQ_CD,
               A.SCHED_SECTION_CD,
               TIME_UNIT           = (SELECT   RTRIM(LTRIM(E.ELE_VALUE_DESC_TXT))
                                      FROM        TREFTAB E
                                      WHERE     E.REF_GROUP_CD      = @REF_GROUP_CD
                                      AND       E.DATA_ELEMENT_NAME = @BENEFIT_UNIT
                                      AND       LTRIM(RTRIM(E.DATA_ELEMENT_CODE)) = LTRIM(RTRIM(A.MAX_CASH_TIME_CD))
                                      AND       A.MAX_WEEKS_CNT <> 0),

               RELATION_TXT        = RTRIM(LTRIM(C.COMMENTS_TEXT)),
               LIMIT_SPOUSE_PCT    =    CASE
                                             WHEN LIMIT_SPOUSE_PCT IS NULL THEN 1
                                             WHEN LIMIT_SPOUSE_PCT  = 0 THEN 1
                                             ELSE LIMIT_SPOUSE_PCT/100
                                        END,
               LIMIT_CHILD_PCT     =    CASE
                                             WHEN LIMIT_CHILD_PCT IS NULL THEN 1
                                             WHEN LIMIT_CHILD_PCT  = 0 THEN 1
                                             ELSE LIMIT_CHILD_PCT/100
                                        END,
               LIMIT_OTHER_PCT     =    CASE
                                             WHEN LIMIT_OTHER_PCT IS NULL THEN 1
                                             WHEN LIMIT_OTHER_PCT  = 0 THEN 1
                                             ELSE LIMIT_OTHER_PCT/100
                                        END,
               RATE_NAMED_INS_FG   = G.RATE_NAMED_INS_FG      --2007/02/27 KAY.YU ADD                                    
     INTO      #TEMP1
     FROM      TPLANPRODUCT A,
               TPRODUCTDETS B,
               TNAMEDINSURED C,
               TPAYMENTDETS D,
               TPOLICYCERTRIDER E,
               TPLANDETS G         --2007/02/27 KAY.YU ADD
     WHERE     E.POLICYCERT_NO      = @POLICYCERT_NO 
     AND       E.END_EFF_DATE       = @dEndEffDt     
     AND       E.RIDER_NO 		    = 0     
     AND       A.PLAN_NO            = E.PLAN_NO           
     AND       A.END_EFF_DATE       = (SELECT MAX(P.END_EFF_DATE) FROM TPLANPRODUCT P WHERE P.PLAN_NO = E.PLAN_NO AND P.END_EFF_DATE <= E.END_EFF_DATE)
     AND       A.PRODUCT_CD         = B.PRODUCT_CD
     AND       C.POLICYCERT_NO      = @POLICYCERT_NO
     AND       C.END_EFF_DATE       = E.END_EFF_DATE
     AND       C.RIDER_NO           = E.RIDER_NO
     AND       D.POLICYCERT_NO      = C.POLICYCERT_NO
     AND       D.END_EFF_DATE       = C.END_EFF_DATE
     AND       A.SCHED_SECTION_CD  IN ( SELECT    F.SCHED_SECTION_CD
                                        FROM      TPOLICYCERTPREMIUM F
                                        WHERE     F.POLICYCERT_NO     = C.POLICYCERT_NO
                                        AND       F.END_EFF_DATE      = C.END_EFF_DATE
                                        AND       F.RIDER_NO          = C.RIDER_NO)
     AND       A.PLAN_NO            = G.PLAN_NO          --2007/02/27 KAY.YU ADD
     AND       A.END_EFF_DATE       = G.END_EFF_DATE     --2007/02/27 KAY.YU ADD

     -------------- RATED PRODUCTS --------------
     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT,
               PLAN_LAYER_CD       = B.PLAN_LAYER_CD,
               PLAN_RATE_CAT_CD    = B.PLAN_RATE_CAT_CD,
               PLAN_RATE_BAND_CD   = B.PLAN_RATE_BAND_CD,
               RATED_INSURED_FG    = 1
     FROM      #TEMP1 A,
               TPOLICYCERTPREMIUM B,
               TPREMLOOKUP C
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO
     AND       B.NAME_INSURED_NO   = A.NAME_INSURED_NO
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       C.PLAN_NO           = B.PLAN_NO
     AND       C.END_EFF_DATE      = A.PLAN_EFF_DATE
     AND       C.PRODUCT_CD        = B.PRODUCT_CD
     AND       C.PLAN_LAYER_CD     = B.PLAN_LAYER_CD
     AND       C.PLAN_RATE_CAT_CD  = B.PLAN_RATE_CAT_CD
     AND       C.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
--     AND       C.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD
     AND       (C.RELATION_CD      = A.RELATION_CD
                                      OR   C.RELATION_CD IN (""," "))


     UPDATE    #TEMP1
     SET       PLAN_LAYER_CD       = B.PLAN_LAYER_CD,
               PLAN_RATE_CAT_CD    = B.PLAN_RATE_CAT_CD,
               PLAN_RATE_BAND_CD   = B.PLAN_RATE_BAND_CD
     FROM      #TEMP1 A,
               #TEMP1 B
     WHERE     A.RATED_INSURED_FG  = 0
     and       B.RATED_INSURED_FG  = 1
     /*AND       A.NAME_INSURED_NO = B.NAME_INSURED_NO*/           --2007/02/27 KAY.YU CHANGE
     AND       ((A.NAME_INSURED_NO = B.NAME_INSURED_NO AND A.RATE_NAMED_INS_FG='Y')
                OR
                (A.RATE_NAMED_INS_FG='N') 
                )
--     AND       B.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD


     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT * B.LIMIT_SPOUSE_PCT,
               RATED_INSURED_FG    = 1
     FROM      #TEMP1 A,
               #TEMP1 B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       A.RELATION_CD       = "S"
     AND       B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.RATED_INSURED_FG  = 1


     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT * B.LIMIT_CHILD_PCT,
               RATED_INSURED_FG    = 1
     FROM      #TEMP1 A,
               #TEMP1 B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       A.RELATION_CD       = "D"
     AND       B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.RATED_INSURED_FG  = 1


     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT * B.LIMIT_OTHER_PCT,
               RATED_INSURED_FG    = 1
     FROM      #TEMP1 A,
               #TEMP1 B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       A.RELATION_CD       = "O"
     AND       B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.RATED_INSURED_FG  = 1


     ------------- NON-RATED PRODUCT --------------
     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = CASE
                                        WHEN A.RELATION_CD = "P" THEN B.BENEFIT_AMT
                                        WHEN A.RELATION_CD = "S" AND B.SPO_BENEFIT_TYPE ="A" THEN B.SPOUSE_BENEFIT
                                        WHEN A.RELATION_CD = "S" AND B.SPO_BENEFIT_TYPE ="P" THEN (B.SPOUSE_BENEFIT/100) * B.BENEFIT_AMT
                                        WHEN A.RELATION_CD = "D" AND B.SPO_BENEFIT_TYPE ="A" THEN B.DEPENDENT_BENEFIT
                                        WHEN A.RELATION_CD = "D" AND B.SPO_BENEFIT_TYPE ="P" THEN (B.DEPENDENT_BENEFIT/100) * B.BENEFIT_AMT
                                        WHEN A.RELATION_CD = "O" AND B.SPO_BENEFIT_TYPE ="A" THEN B.OTHER_ADULT
                                        WHEN A.RELATION_CD = "O" AND B.SPO_BENEFIT_TYPE ="P" THEN (B.OTHER_ADULT/100) * B.BENEFIT_AMT
                                        WHEN A.RELATION_CD = "T" AND B.SPO_BENEFIT_TYPE ="A" THEN B.STUDENT_BENEFIT
                                        WHEN A.RELATION_CD = "T" AND B.SPO_BENEFIT_TYPE ="P" THEN (B.STUDENT_BENEFIT/100) * B.BENEFIT_AMT
                                        ELSE	0
                                     END
     FROM      #TEMP1 A,
               TBENEFITLOOKUP B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.END_EFF_DATE      = A.PLAN_EFF_DATE
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.PLAN_LAYER_CD     = A.PLAN_LAYER_CD
     AND       B.PLAN_RATE_CAT_CD  = A.PLAN_RATE_CAT_CD
     AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD
--     AND       B.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD


     SELECT    PRODUCT_CD,
               PRODUCT_NAME        = MAX(PRODUCT_NAME),
               BENEFIT_INSURED     = CONVERT(MONEY,NULL),
               BENEFIT_SPOUSE      = CONVERT(MONEY,NULL),
               BENEFIT_CHILD       = CONVERT(MONEY,NULL),
               BENEFIT_PARENT      = CONVERT(MONEY,NULL),
               TIME_UNIT           = MAX(TIME_UNIT)
     INTO      #FINAL
     FROM      #TEMP1 A
     GROUP BY  PRODUCT_CD

     UPDATE    #FINAL
     SET       BENEFIT_SPOUSE       = ( SELECT    MAX(BENEFIT_AMT)
                                        FROM      #TEMP1 B
                                        WHERE     B.PRODUCT_CD   = A.PRODUCT_CD
                                        AND       B.RELATION_CD  = "S"),
               BENEFIT_CHILD        = ( SELECT    MAX(BENEFIT_AMT)
                                        FROM      #TEMP1 B
                                        WHERE     B.PRODUCT_CD   = A.PRODUCT_CD
                                        AND       B.RELATION_CD  = "D"),
               BENEFIT_INSURED      = ( SELECT    MAX(BENEFIT_AMT)
                                        FROM      #TEMP1 B
                                        WHERE     B.PRODUCT_CD   = A.PRODUCT_CD
                                        AND       B.RELATION_CD  = "P"),
			   BENEFIT_PARENT       = ( SELECT    MAX(BENEFIT_AMT)
                                        FROM      #TEMP1 B
                                        WHERE     B.PRODUCT_CD   = A.PRODUCT_CD
                                        AND       B.RELATION_CD  = "O")
     FROM      #FINAL A

     SELECT 	#FINAL.PRODUCT_CD, 
     			#FINAL.PRODUCT_NAME, 
     			#FINAL.BENEFIT_INSURED, 
     			#FINAL.BENEFIT_SPOUSE, 
     			#FINAL.BENEFIT_CHILD, 
     			#FINAL.BENEFIT_PARENT,
     			#FINAL.TIME_UNIT 
     FROM 		#FINAL
END

go
IF OBJECT_ID('dbo.WSM_BENEFITS_CORE') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_BENEFITS_CORE >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_BENEFITS_CORE >>>'
go
GRANT EXECUTE ON dbo.WSM_BENEFITS_CORE TO userall 
go

print "After"
go
sp_help WSM_BENEFITS_CORE
go