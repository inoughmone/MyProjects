print "Before"
go
sp_help WSM_BENEFITS_UPGRADED
go

IF OBJECT_ID('dbo.WSM_BENEFITS_UPGRADED') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_BENEFITS_UPGRADED
    IF OBJECT_ID('dbo.WSM_BENEFITS_UPGRADED') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_BENEFITS_UPGRADED >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_BENEFITS_UPGRADED >>>'
END
go
/*
****************************************************************************************************
TITLE				: WSM_BENEFITS_UPGRADED
AUTHOR		  : MPHASIS
DATE		    : 11/17/2006
DESCRIPTION	: THIS STORED PROCEDURE IS USED FOR UPGRADED PLANS
                Remove the PUB_RATE_INT_CD condition for non-rated product

USE FOR			:
****************************************************************************************************
*/
CREATE PROCEDURE DBO.WSM_BENEFITS_UPGRADED
     @POLICYCERT_NO      VARCHAR(14),
     @END_EFF_DATE       DATETIME,
     @RIDER_NO           SMALLINT,
     @REF_GROUP_CD       CHAR(6)   = "061000",
     @BENEFIT_UNIT       CHAR(32)  = "BENEFIT-TIME-UNIT"
AS
BEGIN
     DECLARE   @PLAN_NO       CHAR(5),
               @PLAN_EFF_DATE DATETIME,
               @Base_PLAN_NO       CHAR(5),
               @Base_PLAN_EFF_DATE DATETIME


     SELECT    @PLAN_NO            = A.PLAN_NO
     FROM      TPOLICYCERTRIDER A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.END_EFF_DATE      = @END_EFF_DATE
     AND       A.RIDER_NO          = @RIDER_NO

     SELECT    @PLAN_EFF_DATE      = MAX(END_EFF_DATE)
     FROM      TPLANPRODUCT
     WHERE     PLAN_NO             = @PLAN_NO
     AND       END_EFF_DATE        <= @END_EFF_DATE
     
     SELECT    @Base_PLAN_NO       = A.PLAN_NO
     FROM      TPOLICYCERTRIDER A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.RIDER_NO          = 0
     AND       A.LATEST_VERSION_FG = 'Y'
     
     SELECT    @Base_PLAN_EFF_DATE = MAX(END_EFF_DATE)
     FROM      TPLANPRODUCT
     WHERE     PLAN_NO             = @Base_PLAN_NO
     AND       END_EFF_DATE        <= @END_EFF_DATE


     SELECT    C.POLICYCERT_NO,
               C.END_EFF_DATE,
               C.RIDER_NO,
               C.NAME_INSURED_NO,
               A.PLAN_NO,
               PLAN_EFF_DATE       = A.END_EFF_DATE,
               A.PRODUCT_CD,
               B.PRODUCT_NAME,
               C.RELATION_CD,
               BENEFIT_AMT         = CONVERT(MONEY,0),
               BASE_BENEFIT_AMT    = CONVERT(MONEY,0),
               PLAN_LAYER_CD       = SPACE(10),
               PLAN_RATE_CAT_CD    = SPACE(10),
               PLAN_RATE_BAND_CD   = SPACE(10),
               RATED_INSURED_FG    = CONVERT(INT,0),
               PUB_RATE_INT_CD     = D.BILL_FREQ_CD,
               A.SCHED_SECTION_CD,
               TIME_UNIT     = (SELECT   RTRIM(LTRIM(E.ELE_VALUE_DESC_TXT))
                                      FROM        TREFTAB E
                                      WHERE     E.REF_GROUP_CD      = @REF_GROUP_CD
                                      AND       E.DATA_ELEMENT_NAME = @BENEFIT_UNIT
                                      AND       LTRIM(RTRIM(E.DATA_ELEMENT_CODE)) = LTRIM(RTRIM(A.MAX_CASH_TIME_CD))
                                      AND       A.MAX_WEEKS_CNT <> 0),
               SORT_NO=convert(int,0)
     INTO      #TEMP1
     FROM      TPLANPRODUCT A,
               TPRODUCTDETS B,
               TNAMEDINSURED C,
               TPAYMENTDETS D
     WHERE     A.PLAN_NO           = @PLAN_NO
     AND       A.END_EFF_DATE      = @PLAN_EFF_DATE
     AND       C.NAME_INSURED_NO   = 0
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       C.POLICYCERT_NO     = @POLICYCERT_NO
     AND       C.END_EFF_DATE      = @END_EFF_DATE
     AND       C.RIDER_NO          = @RIDER_NO
     AND       D.POLICYCERT_NO     = C.POLICYCERT_NO
     AND       D.END_EFF_DATE      = C.END_EFF_DATE
     AND       A.SCHED_SECTION_CD  IN ( SELECT    E.SCHED_SECTION_CD
                                        FROM      TPOLICYCERTPREMIUM E
                                        WHERE     E.POLICYCERT_NO     = C.POLICYCERT_NO
                                        AND       E.END_EFF_DATE      = C.END_EFF_DATE
                                        AND       E.RIDER_NO          = C.RIDER_NO)

     -------------- RATED PRODUCTS --------------
     --Upgraded Benefits
     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT,
               PLAN_LAYER_CD       = B.PLAN_LAYER_CD,
               PLAN_RATE_CAT_CD    = B.PLAN_RATE_CAT_CD,
               PLAN_RATE_BAND_CD   = B.PLAN_RATE_BAND_CD,
               RATED_INSURED_FG    = 1,
			   SORT_NO             = 0 
     FROM      #TEMP1 A,
               TPOLICYCERTPREMIUM B
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO
     AND       B.NAME_INSURED_NO   = A.NAME_INSURED_NO
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     
     --Base Benefits
     IF @RIDER_NO > 0 -- If @RIDER_NO = 0, the plan already is base plan
     BEGIN
         UPDATE    #TEMP1
         SET       BASE_BENEFIT_AMT      = B.BENEFIT_AMT
         FROM      #TEMP1 A,
                   TPOLICYCERTPREMIUM B
         WHERE     B.POLICYCERT_NO       = A.POLICYCERT_NO
         AND       B.RIDER_NO            = 0
         AND       B.NAME_INSURED_NO     = A.NAME_INSURED_NO
         AND       B.PLAN_NO             = @Base_PLAN_NO
         AND       B.PRODUCT_CD          = A.PRODUCT_CD
         AND       B.PLAN_LAYER_CD       = A.PLAN_LAYER_CD
         AND       B.PLAN_RATE_CAT_CD    = A.PLAN_RATE_CAT_CD
         AND       B.PLAN_RATE_BAND_CD   = A.PLAN_RATE_BAND_CD
         AND       B.SCHED_SECTION_CD    = A.SCHED_SECTION_CD
         AND       LATEST_VERSION_FG     = 'Y'
    END
     
     
     UPDATE    #TEMP1
     SET       PLAN_LAYER_CD       = B.PLAN_LAYER_CD,
               PLAN_RATE_CAT_CD    = B.PLAN_RATE_CAT_CD,
               PLAN_RATE_BAND_CD   = B.PLAN_RATE_BAND_CD,
			   SORT_NO             = 1
     FROM      #TEMP1 A,
               #TEMP1 B
     WHERE     A.RATED_INSURED_FG  = 0
     AND	   B.NAME_INSURED_NO   = A.NAME_INSURED_NO
     and       B.RATED_INSURED_FG  = 1
     AND       B.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD
     
     ------------- NON-RATED PRODUCT --------------
     --Upgraded Benefits
     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT
     FROM      #TEMP1 A,
               TBENEFITLOOKUP B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.END_EFF_DATE      = A.PLAN_EFF_DATE
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.PLAN_LAYER_CD     = A.PLAN_LAYER_CD
     AND       B.PLAN_RATE_CAT_CD  = A.PLAN_RATE_CAT_CD
     AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD
     --AND       B.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD
     
     --Base Benefits
     IF @RIDER_NO > 0 -- If @RIDER_NO = 0, the plan already is base plan
     BEGIN
         UPDATE    #TEMP1
         SET       BASE_BENEFIT_AMT    = B.BENEFIT_AMT
         FROM      #TEMP1 A,
                   TBENEFITLOOKUP B
         WHERE     A.RATED_INSURED_FG  = 0
         AND       B.PLAN_NO           = @Base_PLAN_NO
         AND       B.END_EFF_DATE      = @Base_PLAN_EFF_DATE
         AND       B.PRODUCT_CD        = A.PRODUCT_CD
         AND       B.PLAN_LAYER_CD     = A.PLAN_LAYER_CD
         AND       B.PLAN_RATE_CAT_CD  = A.PLAN_RATE_CAT_CD
         AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD
         --AND       B.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD
     END
     
     SELECT    BASE_PLAN_NO = @Base_PLAN_NO,
               PLAN_NO,
               PRODUCT_NAME,
               BENEFIT_AMT,
               BASE_BENEFIT_AMT,
               TIME_UNIT,
               SORT_NO
     FROM      #TEMP1

END

go
IF OBJECT_ID('dbo.WSM_BENEFITS_UPGRADED') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_BENEFITS_UPGRADED >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_BENEFITS_UPGRADED >>>'
go
GRANT EXECUTE ON dbo.WSM_BENEFITS_UPGRADED TO userall 
go

print "After"
go
sp_help WSM_BENEFITS_UPGRADED
go
