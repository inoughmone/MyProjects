print "Before"
go
sp_help WSM_BENEFITS_UPGRADE
go

IF OBJECT_ID('dbo.WSM_BENEFITS_UPGRADE') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.WSM_BENEFITS_UPGRADE
    IF OBJECT_ID('dbo.WSM_BENEFITS_UPGRADE') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.WSM_BENEFITS_UPGRADE >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.WSM_BENEFITS_UPGRADE >>>'
END
go
/*
****************************************************************************************************
TITLE				: WSM_BENEFITS_UPGRADE
AUTHOR		  : MPHASIS
DATE		    : 05/12/2006
DESCRIPTION	: THIS STORED PROCEDURE IS USED FOR UPGRADE PLANS


USE FOR			:
****************************************************************************************************
*/
CREATE PROCEDURE dbo.WSM_BENEFITS_UPGRADE
     @POLICYCERT_NO      VARCHAR(14),
     @END_EFF_DATE       DATETIME,
     @RIDER_NO           SMALLINT,     
     @REF_GROUP_CD       CHAR(6)   = "061000",
     @BENEFIT_UNIT       CHAR(32)  = "BENEFIT-TIME-UNIT"
AS
BEGIN
     DECLARE   @PLAN_NO               CHAR(5),
               @ASS_PLAN_NO           CHAR(5),
               @CAMPAIGN_CD           CHAR(7),
               @ASS_CAMPAIGN_CD       CHAR(7),
               @PLAN_EFF_DATE         DATETIME,
               @ASS_PLAN_EFF_DATE     DATETIME,
               @PRODUCT_CD            CHAR(6),
               @PREMIUM_AMT           MONEY,
               @UPGRADE_PREMIUM_AMT           MONEY


     SELECT    @PLAN_NO            = A.PLAN_NO,
               @CAMPAIGN_CD        = A.CAMPAIGN_CD
     FROM      TPOLICYCERTRIDER A
     WHERE     A.POLICYCERT_NO     = @POLICYCERT_NO
     AND       A.END_EFF_DATE      = @END_EFF_DATE
     AND       A.RIDER_NO          = @RIDER_NO
     
    SELECT    @PLAN_EFF_DATE      = MAX(END_EFF_DATE)
    FROM      TPLANPRODUCT
    WHERE     PLAN_NO             = @PLAN_NO
    AND       END_EFF_DATE        <= @END_EFF_DATE


     SELECT    C.POLICYCERT_NO,
               C.END_EFF_DATE,
               C.RIDER_NO,
               C.NAME_INSURED_NO,
               A.PLAN_NO,
               PLAN_EFF_DATE       = A.END_EFF_DATE,
               A.PRODUCT_CD,
               B.PRODUCT_NAME,
               C.RELATION_CD,
               BENEFIT_AMT         = CONVERT(MONEY,0),
               UPGRADE_BENEFIT_AMT = CONVERT(MONEY,0),
               PREMIUM_AMT         = CONVERT(MONEY,0),
               UPGRADE_PREMIUM_AMT = CONVERT(MONEY,0),
               PLAN_LAYER_CD       = SPACE(10),
               PLAN_RATE_CAT_CD    = SPACE(10),
               PLAN_RATE_BAND_CD   = SPACE(10),
               RATED_INSURED_FG    = CONVERT(INT,0),
               PUB_RATE_INT_CD     = D.BILL_FREQ_CD,
               A.SCHED_SECTION_CD,
               TIME_UNIT           = (SELECT   RTRIM(LTRIM(E.ELE_VALUE_DESC_TXT))
                                      FROM      TREFTAB E
                                      WHERE     E.REF_GROUP_CD      = @REF_GROUP_CD
                                      AND       E.DATA_ELEMENT_NAME = @BENEFIT_UNIT
                                      AND       LTRIM(RTRIM(E.DATA_ELEMENT_CODE)) = LTRIM(RTRIM(A.MAX_CASH_TIME_CD))
                                      AND       A.MAX_WEEKS_CNT <> 0)               
     INTO      #TEMP1
     FROM      TPLANPRODUCT A,
               TPRODUCTDETS B,
               TNAMEDINSURED C,
               TPAYMENTDETS D
    WHERE      A.PLAN_NO           = @PLAN_NO
     AND       A.END_EFF_DATE      = @PLAN_EFF_DATE
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       C.POLICYCERT_NO     = @POLICYCERT_NO
     AND       C.END_EFF_DATE      = @END_EFF_DATE
     AND       C.RIDER_NO          = @RIDER_NO
     AND       C.NAME_INSURED_NO   = 0
     AND       D.POLICYCERT_NO     = C.POLICYCERT_NO
     AND       D.END_EFF_DATE      = C.END_EFF_DATE    
     AND       A.SCHED_SECTION_CD  IN ( SELECT    F.SCHED_SECTION_CD
                                        FROM      TPOLICYCERTPREMIUM F
                                        WHERE     F.POLICYCERT_NO     = C.POLICYCERT_NO
                                        AND       F.END_EFF_DATE      = C.END_EFF_DATE
                                        AND       F.RIDER_NO          = C.RIDER_NO)


     -------------- RATED PRODUCTS --------------
     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT,
               PLAN_LAYER_CD       = B.PLAN_LAYER_CD,
               PLAN_RATE_CAT_CD    = B.PLAN_RATE_CAT_CD,
               PLAN_RATE_BAND_CD   = B.PLAN_RATE_BAND_CD,
               RATED_INSURED_FG    = 1
     FROM      #TEMP1 A,
               TPOLICYCERTPREMIUM B,
               TPREMLOOKUP C
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     AND       B.RIDER_NO          = A.RIDER_NO
     AND       B.NAME_INSURED_NO   = A.NAME_INSURED_NO
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       C.PLAN_NO           = B.PLAN_NO
     AND       C.END_EFF_DATE      = A.PLAN_EFF_DATE
     AND       C.PRODUCT_CD        = B.PRODUCT_CD
     AND       C.PLAN_LAYER_CD     = B.PLAN_LAYER_CD
     AND       C.PLAN_RATE_CAT_CD  = B.PLAN_RATE_CAT_CD
     AND       C.PLAN_RATE_BAND_CD = B.PLAN_RATE_BAND_CD
     AND       (C.RELATION_CD      = A.RELATION_CD
                                      OR   C.RELATION_CD IN (""," "))


     UPDATE    #TEMP1
     SET       PLAN_LAYER_CD       = B.PLAN_LAYER_CD,
               PLAN_RATE_CAT_CD    = B.PLAN_RATE_CAT_CD,
               PLAN_RATE_BAND_CD   = B.PLAN_RATE_BAND_CD
     FROM      #TEMP1 A,
               #TEMP1 B
     WHERE     A.RATED_INSURED_FG  = 0
     and       B.RATED_INSURED_FG  = 1
--     AND       B.PUB_RATE_INT_CD   = A.PUB_RATE_INT_CD

     ------------- NON-RATED PRODUCT --------------
     UPDATE    #TEMP1
     SET       BENEFIT_AMT         = B.BENEFIT_AMT
     FROM      #TEMP1 A,
               TBENEFITLOOKUP B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       B.PLAN_NO           = A.PLAN_NO
     AND       B.END_EFF_DATE      = A.PLAN_EFF_DATE
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.PLAN_LAYER_CD     = A.PLAN_LAYER_CD
     AND       B.PLAN_RATE_CAT_CD  = A.PLAN_RATE_CAT_CD
     AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD

     
   ------------Get the Associate campaign premium and benefit amount.
    SELECT    @ASS_CAMPAIGN_CD = ASSOC_CAMP_CD
    FROM      TCAMPASSOCIATE
    WHERE     MASTER_CAMP_CD = @CAMPAIGN_CD
    
    
    SELECT      @ASS_PLAN_NO      = CP.PLAN_NO
    FROM        TCAMPPLAN CP      
    WHERE       CAMPAIGN_CD  = @ASS_CAMPAIGN_CD    
    AND         END_EFF_DATE = (SELECT MAX(END_EFF_DATE) FROM TCAMPPLAN WHERE CAMPAIGN_CD  = @ASS_CAMPAIGN_CD)
        
        
    SELECT    @ASS_PLAN_EFF_DATE      = MAX(END_EFF_DATE)
    FROM      TPLANPRODUCT
    WHERE     PLAN_NO             = @ASS_PLAN_NO
    AND       END_EFF_DATE        <= @END_EFF_DATE
        
 -------------- RATED PRODUCTS --------------   
    UPDATE    #TEMP1
    SET       UPGRADE_BENEFIT_AMT   = B.BENEFIT_AMT       
    FROM      #TEMP1 A,
              TPREMLOOKUP B
    WHERE     A.PRODUCT_CD = B.PRODUCT_CD
    AND       B.PLAN_NO = @ASS_PLAN_NO
    AND       B.END_EFF_DATE = @ASS_PLAN_EFF_DATE    
    AND       B.PLAN_LAYER_CD = A.PLAN_LAYER_CD
    AND       B.PLAN_RATE_CAT_CD = A.PLAN_RATE_CAT_CD
    AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD         

   ------------- NON-RATED PRODUCT --------------
     UPDATE    #TEMP1
     SET       UPGRADE_BENEFIT_AMT         = B.BENEFIT_AMT
     FROM      #TEMP1 A,
               TBENEFITLOOKUP B
     WHERE     A.RATED_INSURED_FG  = 0
     AND       B.PLAN_NO           = @ASS_PLAN_NO
     AND       B.END_EFF_DATE      = @ASS_PLAN_EFF_DATE
     AND       B.PRODUCT_CD        = A.PRODUCT_CD
     AND       B.PLAN_LAYER_CD     = A.PLAN_LAYER_CD
     AND       B.PLAN_RATE_CAT_CD  = A.PLAN_RATE_CAT_CD
     AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD     

    SELECT    @PRODUCT_CD = PRODUCT_CD
    FROM      TPLANPRODUCT
    WHERE     PLAN_NO = @ASS_PLAN_NO
    AND       END_EFF_DATE = @ASS_PLAN_EFF_DATE
    AND       RATED_ITEM_FG = 'Y'
      
    SELECT    @UPGRADE_PREMIUM_AMT = SUM(B.PREMIUM_AMT),
              @PREMIUM_AMT         = SUM(A.PREMIUM_AMT)
    FROM      TPOLICYCERTPREMIUM A,
              TPREMLOOKUP B
    WHERE     A.POLICYCERT_NO = @POLICYCERT_NO
    AND       A.END_EFF_DATE = @END_EFF_DATE
    AND       A.RIDER_NO = @RIDER_NO
    AND       A.PRODUCT_CD = @PRODUCT_CD
    AND       B.PLAN_NO = @ASS_PLAN_NO
    AND       B.END_EFF_DATE = @ASS_PLAN_EFF_DATE
    AND       B.PRODUCT_CD = @PRODUCT_CD
    AND       B.PLAN_LAYER_CD = A.PLAN_LAYER_CD
    AND       B.PLAN_RATE_CAT_CD = A.PLAN_RATE_CAT_CD
    AND       B.PLAN_RATE_BAND_CD = A.PLAN_RATE_BAND_CD    
    
    SELECT    PRODUCT_CD, 
     	      PRODUCT_NAME,
     	      @PREMIUM_AMT AS PREMIUM_AMT ,
     	      @UPGRADE_PREMIUM_AMT AS UPGRADE_PREMIUM_AMT,
     	      BENEFIT_AMT,
     	      UPGRADE_BENEFIT_AMT,
              TIME_UNIT     					
    FROM      #TEMP1
END

go
IF OBJECT_ID('dbo.WSM_BENEFITS_UPGRADE') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.WSM_BENEFITS_UPGRADE >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.WSM_BENEFITS_UPGRADE >>>'
go
GRANT EXECUTE ON dbo.WSM_BENEFITS_UPGRADE TO userall 
go

print "After"
go
sp_help WSM_BENEFITS_UPGRADE
go