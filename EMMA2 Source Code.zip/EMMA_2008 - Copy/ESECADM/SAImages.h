//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SAImages.rc
//
#define IDI_CONNECT		    50
#define IDI_DISCONN		    51
#define IDI_SECADM                 100
#define IDI_USERGRP                101
#define IDI_USERGRP_NEW            102
#define IDI_USERGRP_EDT            103
#define IDI_USERGRP_DEL            104

#define IDI_USER	           106
#define IDI_USER_NEW	           107
#define IDI_USER_EDT    	   108
#define IDI_USER_DEL	           109

#define IDI_APP_NEW	           116
#define IDI_APP_EDT    	   	   117
#define IDI_APP_DEL	           118

#define IDI_CALENDAR       	   150

#define IDB_DB16		   200
#define IDB_GROUP16		   201
#define IDB_USER16		   202
#define IDB_APP16		   203
#define IDB_ITEM16		   204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           208
#endif
#endif
