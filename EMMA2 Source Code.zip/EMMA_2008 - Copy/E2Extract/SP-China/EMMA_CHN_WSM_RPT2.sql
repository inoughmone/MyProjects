IF OBJECT_ID('dbo.EMMA_CHN_WSM_RPT2') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.EMMA_CHN_WSM_RPT2
    IF OBJECT_ID('dbo.EMMA_CHN_WSM_RPT2') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.EMMA_CHN_WSM_RPT2 >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.EMMA_CHN_WSM_RPT2 >>>'
END
go

/*
****************************************************************************************************
TITLE             : EMMA_CHN_WSM_RPT2
AUTHOR            : MPHASIS
DATE              : 08/25/2006
DESCRIPTION       : THIS STORED PROCEDURE IS USED AS MAIN SP FOR RPT2 REPORT
                    Add contact information (Modify)
                    Add back_account_name (Modify)
USE FOR           :
****************************************************************************************************
*/
CREATE PROCEDURE dbo.EMMA_CHN_WSM_RPT2
     @JOB_NO   INT,
     @REF_GROUP_CD       CHAR(6)   = "061000",
     @DATA_ELEMENT_NAME  CHAR(32)  = "BANK-BRANCH-ACCT"
AS
BEGIN
     DECLARE   @BILLING_ORG_CD     CHAR(6),
               @BILLING_TRANS_NO   INT,
               @PAYMENT_FREQ_CD    CHAR,
               @CRITERIA1_TXT      CHAR(254),
               @METH_OF_PAYM_CD    CHAR(4)

     SELECT    @CRITERIA1_TXT  = LTRIM(RTRIM(A.CRITERIA1_TXT))
     FROM      TPRINTQUEUE A
     WHERE     A.PRINT_JOB_NO      = @JOB_NO

     SELECT    @METH_OF_PAYM_CD    = "BANK"

     SELECT    @BILLING_ORG_CD     = SUBSTRING(@CRITERIA1_TXT,1,CHARINDEX(",",@CRITERIA1_TXT)-1)
     SELECT    @CRITERIA1_TXT      = SUBSTRING(@CRITERIA1_TXT,CHARINDEX(",",@CRITERIA1_TXT)+1,254)

     SELECT    @BILLING_TRANS_NO   = CONVERT(INT,SUBSTRING(@CRITERIA1_TXT,1,CHARINDEX(",",@CRITERIA1_TXT)-1))
     SELECT    @CRITERIA1_TXT      = SUBSTRING(@CRITERIA1_TXT,CHARINDEX(",",@CRITERIA1_TXT)+1,254)

     SELECT    @PAYMENT_FREQ_CD    = @CRITERIA1_TXT
     
     /* 
          Requirements:
          1.  Policycertificate 
          2.  Insure plan (rider 0)
          3.  
     
        Certificate No.	Insured Plan	Employer	Employee	Premium Payable	Policy Holder Name	National ID	Insured Name
     */
     

     SELECT    A.POLICYCERT_NO,
               END_EFF_DATE        = (  SELECT    MAX(C.END_EFF_DATE)
                                        FROM      TPOLICYCERTRIDER C
                                        WHERE     C.POLICYCERT_NO = A.POLICYCERT_NO
                                        AND       C.END_EFF_DATE  <= A.BILLED_ON_DATE),
               A.BILLED_ON_DATE,
               A.BANK_CD,
               A.BILLING_AMT,
               B.CONTRIB_TYPE,
               EMPLOYER_SHARE      = 0,
               EMPLOYEE_SHARE      = 0
     INTO      #TEMP_TRXN               
     FROM      TBILLTRXN A,
               TCAMPAIGNBILLFREQ B
     WHERE     A.BILLING_ORG_CD    = @BILLING_ORG_CD
     AND       A.BILLING_TRANS_NO  = @BILLING_TRANS_NO
     AND       A.BILL_INTERVAL_CD  = @PAYMENT_FREQ_CD
     AND       A.METH_OF_PAYM_CD   = @METH_OF_PAYM_CD
     AND       B.CAMPAIGN_CD       = A.CAMPAIGN_CD
     and       B.METH_OF_PAYM_CD   =A.METH_OF_PAYM_CD
     AND       B.BANK_CD           = A.BANK_CD
     AND       B.METH_OF_PAYM_CD   = A.METH_OF_PAYM_CD
     AND       B.BILL_INTERVAL_CD  = A.BILL_INTERVAL_CD
     AND       B.CONTRIB_TYPE IN ("E","R","S")


     /* -------------- GET EMPLOYER SHARE -------------- */
     UPDATE    #TEMP_TRXN
     SET       EMPLOYER_SHARE = CASE
                                   WHEN B.CONTRIB_VALTYP = "P" THEN  (A.BILLING_AMT * (B.CONTRIB_VALUE/100))
                                   ELSE B.CONTRIB_VALUE
                                END
     FROM      #TEMP_TRXN A,
               TBANKDETS_EXT B
     WHERE     B.BANK_CD      = A.BANK_CD

     /* ---------- ALL SHOULDERED BY EMPLOYEE ------------- */
     UPDATE    #TEMP_TRXN
     SET       EMPLOYEE_SHARE = BILLING_AMT,
               EMPLOYER_SHARE = 0
     WHERE     CONTRIB_TYPE   = "E"

     /* ---------- ALL SHOULDERED BY EMPLOYER ------------- */
     UPDATE    #TEMP_TRXN
     SET       EMPLOYER_SHARE = BILLING_AMT,
               EMPLOYEE_SHARE = 0
     WHERE     CONTRIB_TYPE   = "R"


     /* ---------- PART SHOULDER BY EMPLOYEE ------------- */
     UPDATE    #TEMP_TRXN
     SET       EMPLOYEE_SHARE = ABS(BILLING_AMT - EMPLOYER_SHARE)
     WHERE     CONTRIB_TYPE   = "S"

     SELECT    POLICYCERT_NO,
               END_EFF_DATE        = MAX(END_EFF_DATE),
               BILLED_ON_DATE      = MIN(BILLED_ON_DATE),
               BILLED_ON_DATE2     = MAX(BILLED_ON_DATE),
               BILLING_AMT         = SUM(BILLING_AMT),
               EMPLOYER_SHARE      = SUM(EMPLOYER_SHARE),
               EMPLOYEE_SHARE      = SUM(EMPLOYEE_SHARE),
               PLAN_NO             = SPACE(5),
               ISSUING_BRNCH_CD    = SPACE(10),
               INSURED_COUNT       = CONVERT(INT,0),
               POLICY_HOLDER       = SPACE(100),
               SOCIAL_SEC_NO       = SPACE(20)
     INTO      #TEMP_OUTPUT
     FROM      #TEMP_TRXN
     GROUP BY  POLICYCERT_NO
     

     UPDATE    #TEMP_OUTPUT
     SET       ISSUING_BRNCH_CD    = (  SELECT    MAX(B.ISSUING_BRNCH_CD)
                                        FROM      TPOLICYCERTRIDER B
                                        WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       B.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       B.RIDER_NO          = 0),
               PLAN_NO             = (  SELECT    MAX(C.PLAN_NO)
                                        FROM      TPOLICYCERTRIDER C
                                        WHERE     C.POLICYCERT_NO     = A.POLICYCERT_NO
                                        AND       C.END_EFF_DATE      = A.END_EFF_DATE
                                        AND       C.RIDER_NO          = 0),
               POLICY_HOLDER       = LTRIM(RTRIM(F.PHOLD_FAMILY_NAME + " " + F.PHOLD_GIVEN_NAME)),
               SOCIAL_SEC_NO       = LTRIM(RTRIM(F.SOCIAL_SEC_NO))
     FROM      #TEMP_OUTPUT A,
               TPOLICYCERT E,
               TPOLICYCERTHOLDER F
     WHERE     E.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       F.POLICY_HOLDER_NO  = E.POLICY_HOLDER_NO

     SELECT    A.POLICYCERT_NO,
               A.END_EFF_DATE,
               A.BILLED_ON_DATE,
               A.BILLING_AMT,
               A.EMPLOYER_SHARE,
               A.EMPLOYEE_SHARE,
               A.PLAN_NO,
               A.ISSUING_BRNCH_CD,
               A.INSURED_COUNT,
               A.POLICY_HOLDER,
               A.SOCIAL_SEC_NO,
               EXT_POLICY_NO            = RTRIM(B.EXT_POLICY_NO),
               BILLED_ON_EXPIRY         = CASE
                                             WHEN @PAYMENT_FREQ_CD = "A" THEN DATEADD(YEAR,1,A.BILLED_ON_DATE2)
                                             WHEN @PAYMENT_FREQ_CD = "H" THEN DATEADD(MONTH,6,A.BILLED_ON_DATE2)
                                             WHEN @PAYMENT_FREQ_CD = "Q" THEN DATEADD(MONTH,3,A.BILLED_ON_DATE2)
                                             WHEN @PAYMENT_FREQ_CD = "M" THEN DATEADD(MONTH,1,A.BILLED_ON_DATE2)
                                             WHEN @PAYMENT_FREQ_CD = "W" THEN DATEADD(WEEK,1,A.BILLED_ON_DATE2)
                                             ELSE DATEADD(MONTH,1,A.BILLED_ON_DATE2)
                                          END,
               PLAN_NAME                = B.PLAN_NAME,
               C.BILLING_ORG_CD,
               C.BILLING_ORG_NAME,
               D.ISS_BRCH_CNTY_ADDR,
               D.ISS_BRNCH_1_ADDR,
               FAX_NO                   = D.ISS_BRNCH_4_ADDR,
               TOTAL_PER_MASTER         = CONVERT(MONEY,0),
               TOTAL_POL_PER_MASTER     = CONVERT(INT,0)
     INTO      #FINAL_TABLE1
     FROM      #TEMP_OUTPUT A,
               TPLANDETS B,
               TBILLORG C,
               TISSUEBRANCH D
     WHERE     B.PLAN_NO           = A.PLAN_NO
     AND       B.END_EFF_DATE      = (  SELECT    MAX(C.END_EFF_DATE)
                                        FROM      TPLANDETS C
                                        WHERE     C.PLAN_NO      = A.PLAN_NO
                                        AND       C.END_EFF_DATE <= A.END_EFF_DATE)
     AND       C.BILLING_ORG_CD    = @BILLING_ORG_CD
     AND       D.ISSUING_BRNCH_CD  = A.ISSUING_BRNCH_CD
     ORDER BY  B.EXT_POLICY_NO, A.POLICYCERT_NO,  A.PLAN_NO
     

     SELECT    BILLING_ORG_CD,
               EXT_POLICY_NO,
               POLICYCERT_NO,
               SOCIAL_SEC_NO,
               END_EFF_DATE                  = MAX(END_EFF_DATE),
               PLAN_NO                       = MAX(PLAN_NO),
               BILLED_ON_DATE                = MIN(BILLED_ON_DATE),
               INSURED_COUNT                 = MAX(INSURED_COUNT),
               EMPLOYER_SHARE                = SUM(EMPLOYER_SHARE),
               EMPLOYEE_SHARE                = SUM(EMPLOYEE_SHARE),
               BILLING_AMT                   = SUM(BILLING_AMT),
               POLICY_HOLDER                 = MAX(POLICY_HOLDER),
               BILLED_ON_EXPIRY              = MAX(BILLED_ON_EXPIRY),
               BILLING_ORG_NAME              = MAX(BILLING_ORG_NAME),
               ISSUING_BRNCH_CD              = MAX(ISSUING_BRNCH_CD),
               TOTAL_PER_MASTER              = CONVERT(MONEY,0),
               TOTAL_POL_PER_MASTER          = CONVERT(INT,0),
               FAX_NO                        = MAX(FAX_NO),
               PLAN_NAME                     = MAX(PLAN_NAME),
               ISS_BRCH_CNTY_ADDR            = MAX(ISS_BRCH_CNTY_ADDR),
               ISS_BRNCH_NAME                = MAX(ISS_BRNCH_1_ADDR)
     INTO      #FINAL_TABLE
     FROM      #FINAL_TABLE1
     GROUP BY  BILLING_ORG_CD,
               EXT_POLICY_NO,
               POLICYCERT_NO,
               SOCIAL_SEC_NO

     UPDATE    #FINAL_TABLE
     SET       TOTAL_PER_MASTER    = (  SELECT    SUM(B.BILLING_AMT)
                                        FROM      #FINAL_TABLE B
                         			WHERE     B.EXT_POLICY_NO = A.EXT_POLICY_NO),
               TOTAL_POL_PER_MASTER = ( SELECT    COUNT(100)
                                      	FROM      #FINAL_TABLE B
                                        WHERE     B.EXT_POLICY_NO = A.EXT_POLICY_NO)
     FROM      #FINAL_TABLE A
/*-- PHD200048487.BEGIN - Comment out
     SELECT    DISTINCT  A.*,
               		INSURED_NAME        = LTRIM(RTRIM(B.NAM_INS_FAM_NAME + " " + B.NAM_INS_GIVEN_NAME)),
          			B.NAME_INSURED_NO   
     INTO      #LAST_TABLE
     FROM 	   #FINAL_TABLE A,
               TNAMEDINSURED B
     WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
     AND       B.END_EFF_DATE      = A.END_EFF_DATE
     

     UPDATE    #LAST_TABLE
     SET       BILLING_AMT         = 0,
               EMPLOYER_SHARE      = 0,
               EMPLOYEE_SHARE      = 0,
               SOCIAL_SEC_NO       = SPACE(0)
     WHERE     NAME_INSURED_NO     > 1
     
     UPDATE    #LAST_TABLE
     SET       INSURED_COUNT       = (  SELECT    MAX(B.NAME_INSURED_NO)
                                        FROM      #LAST_TABLE B
                                        WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO)
     FROM      #LAST_TABLE A
*/ --PHD200048487.END

     --PHD200048487.BEGIN
     UPDATE    #FINAL_TABLE
     SET       INSURED_COUNT       = (  SELECT    MAX(B.NAME_INSURED_NO)
                                        FROM      TNAMEDINSURED B
                                        WHERE     B.POLICYCERT_NO     = A.POLICYCERT_NO
                                             AND  B.END_EFF_DATE      = A.END_EFF_DATE
                                             AND  B.RIDER_NO = 0)
     FROM      #FINAL_TABLE A
     --PHD200048487.END

     SELECT    A.BILLING_ORG_CD, A.EXT_POLICY_NO, A.POLICYCERT_NO, A.SOCIAL_SEC_NO, A.END_EFF_DATE, A.PLAN_NO, A.BILLED_ON_DATE, A.INSURED_COUNT, A.EMPLOYER_SHARE, A.EMPLOYEE_SHARE, A.BILLING_AMT, A.POLICY_HOLDER, A.BILLED_ON_EXPIRY, A.BILLING_ORG_NAME, A.ISSUING_BRNCH_CD, A.TOTAL_PER_MASTER, A.TOTAL_POL_PER_MASTER, A.FAX_NO, A.PLAN_NAME, A.ISS_BRCH_CNTY_ADDR, A.ISS_BRNCH_NAME,
               INSURED_NAME = "       ",
               NAME_INSURED_NO = 0,
               FREQ_CODE      = @PAYMENT_FREQ_CD,
               C.BANK_NAME,
               C.AIG_ACCT_NO,
               -- PHD200065786.BEGIN
               CONTACTINFO              = CONVERT(VARCHAR(50), ''),
               -- PHD200065786.END
               -- PHD200085123.BEGIN
               BANK_ACCT_NAME              = CONVERT(VARCHAR(50), '')
               -- PHD200085123.END
     INTO      #TEMP_LAST
--     FROM      #LAST_TABLE a,    --PHD200048487
     FROM      #FINAL_TABLE a,
               TREFTAB B,
               TBANKDETS C
     WHERE     B.REF_GROUP_CD      = @REF_GROUP_CD
     AND       B.DATA_ELEMENT_NAME = @DATA_ELEMENT_NAME
     AND       B.DATA_ELEMENT_CODE = A.ISSUING_BRNCH_CD
     AND       C.BANK_CD           = LTRIM(RTRIM(B.ELE_VALUE_DESC_TXT))
     AND       C.STATUS_CD         = "A"
     order by  EXT_POLICY_NO,POLICYCERT_NO, SOCIAL_SEC_NO DESC
     
     -- PHD200065786.BEGIN  ..Add contact information
     UPDATE    #TEMP_LAST
     SET       CONTACTINFO         = B.ELE_VALUE_DESC_TXT
     FROM      #TEMP_LAST A, TREFTAB B
     WHERE     LTRIM(RTRIM(B.DATA_ELEMENT_CODE)) = A.ISSUING_BRNCH_CD
     AND       B.REF_GROUP_CD      = @REF_GROUP_CD
     AND       B.DATA_ELEMENT_NAME = 'RPT2-CONTACTINFO-CH'
     -- PHD200065786.END
     
      -- PHD200085123.BEGIN  ..Add bank account name information
     UPDATE    #TEMP_LAST
     SET       BANK_ACCT_NAME         = B.ELE_VALUE_DESC_TXT
     FROM      #TEMP_LAST A, TREFTAB B
     WHERE     LTRIM(RTRIM(B.DATA_ELEMENT_CODE)) = A.ISSUING_BRNCH_CD
     AND       B.REF_GROUP_CD      = @REF_GROUP_CD
     AND       B.DATA_ELEMENT_NAME = 'BANK-ACCOUNT-NAME'
     -- PHD200085123.END

     SELECT    A.BILLING_ORG_CD, A.EXT_POLICY_NO, A.POLICYCERT_NO, A.SOCIAL_SEC_NO, A.END_EFF_DATE, A.PLAN_NO, A.BILLED_ON_DATE, A.INSURED_COUNT, A.EMPLOYER_SHARE, A.EMPLOYEE_SHARE, A.BILLING_AMT, A.POLICY_HOLDER, A.BILLED_ON_EXPIRY, A.BILLING_ORG_NAME, A.ISSUING_BRNCH_CD, A.TOTAL_PER_MASTER, A.TOTAL_POL_PER_MASTER, A.FAX_NO, A.PLAN_NAME, A.ISS_BRCH_CNTY_ADDR, A.ISS_BRNCH_NAME, A.INSURED_NAME, A.NAME_INSURED_NO, A.FREQ_CODE, A.BANK_NAME, A.AIG_ACCT_NO,
               -- PHD200065786.BEGIN
               CONTACTINFO,
               -- PHD200065786.END
               -- PHD200085123.BEGIN
               BANK_ACCT_NAME
               -- PHD200085123.END
     FROM      #TEMP_LAST A
     ORDER BY  EXT_POLICY_NO,
--PHD200048487.start
--               SOCIAL_SEC_NO,
--               POLICYCERT_NO
               POLICYCERT_NO,
               SOCIAL_SEC_NO
--PHD200048487.end

END
go
EXEC sp_procxmode 'dbo.EMMA_CHN_WSM_RPT2','unchained'
go
IF OBJECT_ID('dbo.EMMA_CHN_WSM_RPT2') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.EMMA_CHN_WSM_RPT2 >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.EMMA_CHN_WSM_RPT2 >>>'
go
GRANT EXECUTE ON dbo.EMMA_CHN_WSM_RPT2 TO userall
go
