print "Before"
go
sp_help EMMA_CHN_BT_SPDB
go
IF OBJECT_ID('dbo.EMMA_CHN_BT_SPDB') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.EMMA_CHN_BT_SPDB
    IF OBJECT_ID('dbo.EMMA_CHN_BT_SPDB') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.EMMA_CHN_BT_SPDB >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.EMMA_CHN_BT_SPDB >>>'
END
go
/*
****************************************************************************************************
TITLE           : EMMA_CHN_BT_SPDB
AUTHOR          : MPHASIS
DATE            : 8/16/2006
DESCRIPTION     : THIS STORED PROCEDURE IS USED TO CREATE TAPE FILES
USE FOR         : CREATING TRAP FILES
****************************************************************************************************
*/
CREATE PROCEDURE EMMA_CHN_BT_SPDB
     @BILLING_ORG_CD     CHAR(6),
     @BILLING_TRANS_NO	INT,
     @TESTCD	CHAR	="N",
     @COUNTRY_CD 		CHAR(3)	= "CHN",
     @TAG_CD			CHAR(18)  = "SPDB-GENERIC",
     @REF_GROUP_CD		CHAR(6)	= "061000",
     @CATEGORY_CD		VARCHAR(6)= "SPDB",
     @LANGUAGE_ID		INT		= 1
AS
BEGIN
     DECLARE   @SPLIT_REJECT CHAR

     SELECT    @SPLIT_REJECT  = SPLIT_REJECTIONS
     FROM      TBILLORG
     WHERE     BILLING_ORG_CD = @BILLING_ORG_CD
     
     IF @TESTCD = "Y"
        SELECT  @SPLIT_REJECT ="N"

     CREATE TABLE #TEMP1 ( SERIAL_NO NUMERIC IDENTITY,
                           BSB_NO  CHAR(3),
                           ACCT_NO CHAR(20),
                           ACCOUT_TYPE CHAR,
                           ACCT_NAME  CHAR(50),
                           ID_NO   VARCHAR(20),
                           PREMIUM_AMT MONEY,
                           BILLING_TRANS_NO INT,
                           POLICYCERT_NO     VARCHAR(14),
                           BILLED_ON_DATE    DATETIME,
                           CLEARING_HOUSE CHAR(6),
                           BILLING_ORG_CD Char(6),
                           ACCOUNT_NO CHAR(20),
                           ACCOUNT_NAME CHAR(45),
                           BILLING_AMT MONEY,
                           EMMA_REJ_CD CHAR(5))
     IF @SPLIT_REJECT ="Y"
     BEGIN
          SELECT    A.BILLING_ORG_CD,
                    A.BILLING_TRANS_NO,
                    A.POLICYCERT_NO,
                    --PHD200065743.Begin 8/21/2006
                    --A.BILLED_ON_DATE,
                    ISNULL(A.ORIGINAL_BILL_DATE,A.BILLED_ON_DATE) AS BILLED_ON_DATE,
                    --PHD200065743.End
                    BSB_NO         = MAX(A.BSB_NO),                    
                    ACCOUNT_NO     = MAX(A.ACCOUNT_NO),
                    ACCOUNT_NAME   = MAX(A.ACCOUNT_NAME),
                    BILLING_AMT    = SUM(A.BILLING_AMT)
          INTO      #TEMP2
          FROM      TBILLTRXN A
          WHERE	    A.BILLING_ORG_CD    = @BILLING_ORG_CD
          AND		A.BILLING_TRANS_NO	= @BILLING_TRANS_NO
          AND		A.BILLING_AMT       <> 0
          GROUP BY  A.BILLING_ORG_CD,
                    A.BILLING_TRANS_NO,
                    A.POLICYCERT_NO,
                    A.BILLED_ON_DATE,
                    --PHD200065743.Begin 8/21/2006
                    A.ORIGINAL_BILL_DATE
                    --PHD200065743.End
          
          INSERT #TEMP1
          SELECT    BSB_NO         = ISNULL((SELECT    D.BANK_ID_CD
                                             FROM      TBANKBRANCH D
                                             WHERE     D.BSB_NO  = A.BSB_NO ),""),
                    ACCOUNT_NO,
                    ACCOUNT_TYPE	= "1",
                    A.ACCOUNT_NAME,
                    ID_NO          = ISNULL(C.SOCIAL_SEC_NO,""),
                    PREMIUM_AMT    = A.BILLING_AMT * 100,
                    A.BILLING_TRANS_NO,
                    A.POLICYCERT_NO,
                    A.BILLED_ON_DATE,
                    CLEARING_HOUSE = @CATEGORY_CD,
                    A.BILLING_ORG_CD,
                    A.ACCOUNT_NO,
                    A.ACCOUNT_NAME,
                    A.BILLING_AMT,
                    SPACE(5)
          FROM		#TEMP2 A,
                    TPOLICYCERT B,
                    TPOLICYCERTHOLDER C
          WHERE     A.POLICYCERT_NO     = B.POLICYCERT_NO
          AND       B.POLICYCERT_NO     = A.POLICYCERT_NO
          AND		C.POLICY_HOLDER_NO	= B.POLICY_HOLDER_NO
          ORDER BY  A.POLICYCERT_NO,
                    --PHD200065743.Begin 8/21/2006
                     --A.BILLED_ON_DATE DESC
                    A.BILLED_ON_DATE  ASC
                    --PHD200065743.End
     END
     ELSE
     BEGIN
     
          SELECT    A.BILLING_ORG_CD,
                    A.BILLING_TRANS_NO,
                    A.POLICYCERT_NO,
                    BILLED_ON_DATE      = MAX(A.BILLED_ON_DATE),
                    ACCOUNT_NO          = MAX(A.ACCOUNT_NO),
                    ACCOUNT_NAME        = MAX(A.ACCOUNT_NAME),
                    BSB_NO              = MAX(A.BSB_NO),
                    BILLING_AMT         = SUM(A.BILLING_AMT)
          INTO      #TEMP3
          FROM		TBILLTRXN A
          WHERE	A.BILLING_ORG_CD    = @BILLING_ORG_CD
          AND		A.BILLING_TRANS_NO	= @BILLING_TRANS_NO
          AND		A.BILLING_AMT       <> 0
          GROUP BY  A.BILLING_ORG_CD,
                    A.BILLING_TRANS_NO,
                    A.POLICYCERT_NO
     
          INSERT    #TEMP1(   BSB_NO,
                              ACCT_NO,
                              ACCOUT_TYPE,
                              ACCT_NAME,
                              ID_NO,
                              PREMIUM_AMT,
                              BILLING_TRANS_NO,
                              POLICYCERT_NO,
                              BILLED_ON_DATE,
                              CLEARING_HOUSE,
                              BILLING_ORG_CD,
                              ACCOUNT_NO,
                              ACCOUNT_NAME,
                              BILLING_AMT,
                              EMMA_REJ_CD)
          SELECT    BSB_NO         = ISNULL((SELECT    D.BANK_ID_CD
                                             FROM      TBANKBRANCH D
                                             WHERE     D.BSB_NO  = A.BSB_NO ),""),
                    ACCOUNT_NO,
                    ACCOUNT_TYPE	= "1",
                    A.ACCOUNT_NAME,
                    ID_NO          = ISNULL(C.SOCIAL_SEC_NO,""),
                    PREMIUM_AMT    = A.BILLING_AMT * 100,
                    A.BILLING_TRANS_NO,
                    A.POLICYCERT_NO,
                    A.BILLED_ON_DATE,
                    CLEARING_HOUSE = @CATEGORY_CD,
                    A.BILLING_ORG_CD,
                    A.ACCOUNT_NO,
                    A.ACCOUNT_NAME,
                    A.BILLING_AMT,
                    SPACE(5)
          FROM		#TEMP3 A,
                    TPOLICYCERT B,
                    TPOLICYCERTHOLDER C
          WHERE     A.POLICYCERT_NO     = B.POLICYCERT_NO
          AND       B.POLICYCERT_NO     = A.POLICYCERT_NO
          AND		C.POLICY_HOLDER_NO	= B.POLICY_HOLDER_NO
          ORDER BY  A.POLICYCERT_NO,
                    --PHD200065743.Begin 8/21/2006
                    --A.BILLED_ON_DATE DESC
                    A.BILLED_ON_DATE  ASC
                    --PHD200065743.End
     END

     SELECT #TEMP1.SERIAL_NO, #TEMP1.BSB_NO, #TEMP1.ACCT_NO, #TEMP1.ACCOUT_TYPE, #TEMP1.ACCT_NAME,
        #TEMP1.ID_NO, #TEMP1.PREMIUM_AMT, #TEMP1.BILLING_TRANS_NO, #TEMP1.POLICYCERT_NO,
        #TEMP1.BILLED_ON_DATE, #TEMP1.CLEARING_HOUSE, #TEMP1.BILLING_ORG_CD, #TEMP1.ACCOUNT_NO,
        #TEMP1.ACCOUNT_NAME, #TEMP1.BILLING_AMT, #TEMP1.EMMA_REJ_CD 
        FROM #TEMP1

END
go
IF OBJECT_ID('dbo.EMMA_CHN_BT_SPDB') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.EMMA_CHN_BT_SPDB >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.EMMA_CHN_BT_SPDB >>>'
go
GRANT EXECUTE ON dbo.EMMA_CHN_BT_SPDB TO userall 
go

print "After"
go
sp_help EMMA_CHN_BT_SPDB
go
