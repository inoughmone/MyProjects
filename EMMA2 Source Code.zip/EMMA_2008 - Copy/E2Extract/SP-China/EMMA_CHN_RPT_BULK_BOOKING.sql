print "Before"
go
sp_help EMMA_CHN_RPT_BULK_BOOKING
go

IF OBJECT_ID('dbo.EMMA_CHN_RPT_BULK_BOOKING') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.EMMA_CHN_RPT_BULK_BOOKING
    IF OBJECT_ID('dbo.EMMA_CHN_RPT_BULK_BOOKING') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.EMMA_CHN_RPT_BULK_BOOKING >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.EMMA_CHN_RPT_BULK_BOOKING >>>'
END
go
/*
****************************************************************************************************
TITLE			    : EMMA_CHN_RPT_BULK_BOOKING
AUTHOR		    : MPHASIS SHANGHAI
DATE		      : 01/20/2007
DESCRIPTION	  : THIS STORED PROCEDURE IS USED FOR Bulk Booking Report.

USE FOR			  : PHD200070454
****************************************************************************************************
*/
CREATE PROCEDURE EMMA_CHN_RPT_BULK_BOOKING
     @START_DATE         DATETIME,
     @END_DATE           DATETIME,
     @ISSUING_BRNCH_CD   CHAR(10),
     @REF_GROUP_CD       CHAR(6)   = "061000",
     @DATA_ELEMENT_NAME  CHAR(15)    = "COVERAGE-CODE",
     @COUNTRY_CD         CHAR(3)   = "CHN"
AS
BEGIN
     
     SELECT    B.COVERAGE_CD,
               D.SPONSOR_NAME,
               B.GOALS_POLICY_NO,
               GOALD_PRODUCER_CD        = SPACE(10),
               PRODUCER_NAME            = SPACE(50),
               COMM_PCT                 = CONVERT(FLOAT,0),
               TAX_PCT                  = CONVERT(FLOAT,0),
               A.REC_EFFECT_DATE,
               A.REC_EXP_DATE,
               COVERAGE_DESC            = LTRIM(RTRIM((     SELECT    MAX(C.ELE_VALUE_DESC_TXT)
                                                            FROM      TREFTAB C
                                                            WHERE     C.REF_GROUP_CD      = @REF_GROUP_CD
                                                            AND       C.DATA_ELEMENT_NAME = @DATA_ELEMENT_NAME
                                                            AND       C.DATA_ELEMENT_CODE = A.COVERAGE_CD))),
               A.CURRENCY_CD,
               AGG_LIAB                 = B.RI_LIAB_AMT,
--               PREMIUM_AMT            = ROUND(CONVERT(FLOAT,A.PREMIUM_AMT + ISNULL(A.STAMP_DUTY_AMT + A.BUS_TAX_AMT,0),NULL),2),
               PREMIUM_AMT            = ROUND(CONVERT(FLOAT,A.PREMIUM_AMT + ISNULL(A.STAMP_DUTY_AMT,0),NULL),2),
               NET_AMOUNT               = CONVERT(MONEY,0,NULL),
               RI_CODE_PCT              = B.RI_LIAB_PCT,
               RI_PREM_PCT              = CONVERT(FLOAT,B.RI_PREM_PCT),
               RI_LIAB_AMT              = CONVERT(FLOAT,0),
---               RI_COMM                  = (A.PREMIUM_AMT + a.STAMP_DUTY_AMT + A.BUS_TAX_AMT) * B.RI_COMM_PCT,
               RI_COMM                  = (A.PREMIUM_AMT + a.STAMP_DUTY_AMT) * B.RI_COMM_PCT,
---               TOTAL_PREMIUM            = A.PREMIUM_AMT + a.STAMP_DUTY_AMT + A.BUS_TAX_AMT,
               TOTAL_PREMIUM            = A.PREMIUM_AMT + a.STAMP_DUTY_AMT ,
               BD_CODE                  = D.APPL_RESTRICT_TEXT,
               B.REIN_STRUCT_CD,
               B.REIN_TYPE_CD,
               B.LAYER_NO,
               B.TREATY_NO,
               B.REINCO_CD,
               B.REINCO_SUB_CD,
               A.PRODUCER_CD,
               A.PROD_SUB_CD,
               A.TRANS_DATE,
               A.EXT_PRODUCT_CD,
               A.RISK_CD,
               D.APPL_SOLIC_DATE,
--               TAX_AMT                  = CONVERT(MONEY,ISNULL(A.STAMP_DUTY_AMT + A.BUS_TAX_AMT,0)),
               TAX_AMT                  = CONVERT(MONEY,ISNULL(A.STAMP_DUTY_AMT ,0)),
               A.PROD_COMM_AMT,
               A.CAMPAIGN_CD,
               POLICY_AMOUNT            = CONVERT(MONEY,0),
               B.RI_COMM_PCT,
               A.TERR_CD,
               A.BILLING_ORG_CD
     INTO      #TEMP
     FROM      TINTRSUM A,
               TINTRSUM_EXT B,
               TCAMPDETS D
     WHERE     B.TRANS_DATE        = A.TRANS_DATE
     AND       B.GOALS_POLICY_NO   = A.GOALS_POLICY_NO
     AND       B.BILLING_ORG_CD    = A.BILLING_ORG_CD
     AND       B.REC_EFFECT_DATE   = A.REC_EFFECT_DATE
     AND       B.REC_EXP_DATE      = A.REC_EXP_DATE
     AND       B.POL_OBJ_ID_NO     = A.POL_OBJ_ID_NO
     AND       B.EXT_PRODUCT_CD    = A.EXT_PRODUCT_CD
     AND       B.RISK_CD           = A.RISK_CD
     AND       B.COVERAGE_CD       = A.COVERAGE_CD
     AND       B.CAMPAIGN_CD       = A.CAMPAIGN_CD
     AND       B.TERR_CD           = A.TERR_CD
     AND       B.REIN_STRUCT_CD    = A.REIN_STRUCT_CD
     AND       B.REIN_TYPE_CD      = A.REIN_TYPE_CD
     AND       B.LAYER_NO          = A.LAYER_NO
     AND       B.TREATY_NO         = A.TREATY_NO
     AND       B.REINCO_CD         = A.REINCO_CD
     AND       B.REINCO_SUB_CD     = A.REINCO_SUB_CD
     AND       ( B.CURRENCY_CD  = A.CURRENCY_CD OR ( B.CURRENCY_CD	IN (""," ") AND A.CURRENCY_CD IS NULL))
     AND       D.CAMPAIGN_CD       = A.CAMPAIGN_CD
     AND       A.TRANS_DATE        >= @START_DATE
     AND       A.TRANS_DATE      <= @END_DATE

     UPDATE    #TEMP
     SET       PRODUCER_CD    = B.PRODUCER_CD,
               PROD_SUB_CD    = B.PROD_SUB_CD,
               COMM_PCT       = DATEDIFF(YEAR,A.APPL_SOLIC_DATE,A.REC_EFFECT_DATE),
               TAX_PCT        = ISNULL(  (SELECT    SUM(D.CHG_PCT) 
                                   FROM      TCOUNTRYTERR D
                                   WHERE     D.COUNTRY_CD	     = @COUNTRY_CD
                                   AND       D.TERR_CD		     = A.TERR_CD
                                   AND       D.CHARGE_EFF_DATE   = (  SELECT    MAX(C.CHARGE_EFF_DATE)
							                                   FROM      TCOUNTRYTERR C
							                                   WHERE     C.COUNTRY_CD   = D.COUNTRY_CD
							                                   AND	     C.TERR_CD      = D.TERR_CD
							                                   AND       C.CHARGE_EFF_DATE < A.TRANS_DATE)),0)
     FROM      #TEMP A,
               #TEMP B
     WHERE     (A.REIN_TYPE_CD IS NOT NULL OR A.REIN_TYPE_CD NOT IN (""," "))
     AND       B.TRANS_DATE        = A.TRANS_DATE
     AND       B.GOALS_POLICY_NO   = A.GOALS_POLICY_NO
     AND       B.BILLING_ORG_CD    = A.BILLING_ORG_CD
     AND       B.REC_EFFECT_DATE   = A.REC_EFFECT_DATE
     AND       B.REC_EXP_DATE      = A.REC_EXP_DATE
     AND       B.EXT_PRODUCT_CD    = A.EXT_PRODUCT_CD
     AND       B.RISK_CD           = A.RISK_CD
     AND       B.COVERAGE_CD       = A.COVERAGE_CD
     AND       B.REIN_STRUCT_CD    = A.REIN_STRUCT_CD
     AND       B.CAMPAIGN_CD       = A.CAMPAIGN_CD
     AND       B.LAYER_NO          = 0
     AND       (B.REIN_TYPE_CD IS NOT NULL OR B.REIN_TYPE_CD NOT IN (""," "))


     UPDATE #TEMP
     SET       PRODUCER_NAME       = B.CO_PAY_COMM_NAME,
               GOALD_PRODUCER_CD   = "0" + A.PRODUCER_CD + A.PROD_SUB_CD,
               COMM_PCT            =    CASE
                                             WHEN A.COMM_PCT =1 THEN B.COMM_1ST_YR_PCT
                                             WHEN A.COMM_PCT =2 THEN B.COMM_2ND_YR_PCT
                                             WHEN A.COMM_PCT =3 THEN B.COMM_3RD_YR_PCT
                                             WHEN A.COMM_PCT =4 THEN B.COMM_4TH_YR_PCT
                                             ELSE B.SUB_RENL_PCT
                                        END
     FROM      #TEMP A,
               TCAMPCOMMISSION B
     WHERE     B.PRODUCER_CD = A.PRODUCER_CD
     AND       B.PROD_SUB_CD  = A.PROD_SUB_CD

     UPDATE    #TEMP     
     SET       PROD_COMM_AMT  = PREMIUM_AMT * (COMM_PCT/100),
               RI_PREM_PCT    = ROUND(RI_PREM_PCT,2)

     UPDATE    #TEMP
     SET       NET_AMOUNT     = PREMIUM_AMT - PROD_COMM_AMT,
               RI_LIAB_AMT    = ROUND(PREMIUM_AMT *  RI_PREM_PCT,2),
               RI_PREM_PCT    = round(RI_PREM_PCT,2) * 100,
               RI_CODE_PCT    = round(RI_CODE_PCT,2) * 100
  

     SELECT    DISTINCT A.COVERAGE_CD, 
               A.SPONSOR_NAME, 
               A.GOALS_POLICY_NO,
               A.BILLING_ORG_CD,
               A.GOALD_PRODUCER_CD, 
               A.PRODUCER_NAME, A.COMM_PCT, A.TAX_PCT, 
               A.REC_EFFECT_DATE, A.REC_EXP_DATE, 
               A.COVERAGE_DESC, A.CURRENCY_CD, A.AGG_LIAB, 
               A.PREMIUM_AMT, A.NET_AMOUNT, A.RI_CODE_PCT, 
               A.RI_PREM_PCT, A.RI_LIAB_AMT, A.RI_COMM, 
               A.TOTAL_PREMIUM, A.BD_CODE, A.REIN_STRUCT_CD, 
               A.REIN_TYPE_CD, A.LAYER_NO, A.TREATY_NO, 
               A.REINCO_CD, A.REINCO_SUB_CD, A.PRODUCER_CD, 
               A.PROD_SUB_CD, A.TRANS_DATE, A.EXT_PRODUCT_CD, A.RISK_CD, 
               A.APPL_SOLIC_DATE, A.TAX_AMT, A.PROD_COMM_AMT, 
               A.CAMPAIGN_CD, A.POLICY_AMOUNT, A.RI_COMM_PCT, 
               A.TERR_CD,                               
               BILLING_ORG_NAME = CONVERT(CHAR(60),""),
               ISS_BRNCH_NAME = CONVERT(CHAR(45),""),
               START_DATE=@START_DATE, END_DATE=@END_DATE, C.REIN_SEQ_NO
     INTO      #OUTPUT
     FROM      #TEMP A,
               TLAYREIN C               
     WHERE     EXISTS (  SELECT 100
               	FROM  TPLANDETS B
                         WHERE     B.EXT_POLICY_NO    = A.GOALS_POLICY_NO
                         AND       B.ISSUING_BRNCH_CD = @ISSUING_BRNCH_CD)
     AND      A.LAYER_NO <> 0
     AND      C.LAYER_NO           = A.LAYER_NO
     AND      C.REIN_TYPE_CD       = A.REIN_TYPE_CD
     AND      C.REIN_STRUCT_CD     = A.REIN_STRUCT_CD
     AND      C.TREATY_NO          = A.TREATY_NO
     AND      C.REINCO_CD          = A.REINCO_CD
     AND      C.REINCO_SUB_CD      = A.REINCO_SUB_CD
     
     
     UPDATE    #OUTPUT
     SET       PREMIUM_AMT    =    (SELECT   B.PREMIUM_AMT
                                    FROM     #TEMP B
                                   WHERE     B.TRANS_DATE        = A.TRANS_DATE
                                   AND       B.GOALS_POLICY_NO   = A.GOALS_POLICY_NO
                                   AND       B.BILLING_ORG_CD    = A.BILLING_ORG_CD
                                   AND       B.REC_EFFECT_DATE   = A.REC_EFFECT_DATE
                                   AND       B.REC_EXP_DATE      = A.REC_EXP_DATE
                                   AND       B.EXT_PRODUCT_CD    = A.EXT_PRODUCT_CD
                                   AND       B.RISK_CD           = A.RISK_CD
                                   AND       B.COVERAGE_CD       = A.COVERAGE_CD
                                   AND       B.CAMPAIGN_CD       = A.CAMPAIGN_CD
                                   AND       B.TERR_CD           = A.TERR_CD
                                   AND       B.LAYER_NO          = 0 ),
               NET_AMOUNT    =    (SELECT   SUM(B.NET_AMOUNT)
                                    FROM     #TEMP  B
                                   WHERE     B.TRANS_DATE        = A.TRANS_DATE
                                   AND       B.GOALS_POLICY_NO   = A.GOALS_POLICY_NO
                                   AND       B.BILLING_ORG_CD    = A.BILLING_ORG_CD
                                   AND       B.REC_EFFECT_DATE   = A.REC_EFFECT_DATE
                                   AND       B.REC_EXP_DATE      = A.REC_EXP_DATE
                                   AND       B.EXT_PRODUCT_CD    = A.EXT_PRODUCT_CD
                                   AND       B.RISK_CD           = A.RISK_CD
                                   AND       B.COVERAGE_CD       = A.COVERAGE_CD
                                   AND       B.CAMPAIGN_CD       = A.CAMPAIGN_CD
                                   AND       B.TERR_CD           = A.TERR_CD
                                   AND       B.LAYER_NO          = 0 )
     FROM      #OUTPUT A

     
     UPDATE    #OUTPUT
     SET       RI_LIAB_AMT    =    (RI_CODE_PCT/100) * PREMIUM_AMT,
               TOTAL_PREMIUM  =    PREMIUM_AMT

     UPDATE    #OUTPUT
     SET       NET_AMOUNT     = NULL,
               PREMIUM_AMT    = NULL
     WHERE     REIN_SEQ_NO    <> 1
     
     UPDATE    #OUTPUT
     SET       ISS_BRNCH_NAME = (SELECT ISS_BRNCH_NAME 
                                 FROM TISSUEBRANCH 
                                 WHERE ISSUING_BRNCH_CD = @ISSUING_BRNCH_CD)
     UPDATE    #OUTPUT                                     
     SET       BILLING_ORG_NAME = B.BILLING_ORG_NAME
     FROM      #OUTPUT A, TBILLORG B
     WHERE     A.BILLING_ORG_CD = B.BILLING_ORG_CD
     
     SELECT    COVERAGE_CD, 
               COVERAGE_DESC,               
               GOALS_POLICY_NO,       --Policy Number 
               SPONSOR_NAME,          --Company Name
               GOALD_PRODUCER_CD, 
               PRODUCER_NAME,
               BILLING_ORG_NAME,
               REC_EFFECT_DATE, 
               REC_EXP_DATE, 
               COMM_PCT,
               CURRENCY_CD,
               AGG_LIAB,              --Sum Insured
               PREMIUM_AMT,           --Gross Premium               
               NET_AMOUNT,                              
               --CAN_REASON_CD = CASE WHEN LEN(RTRIM(TREATY_NO)) > 0 THEN "000" + RTRIM(TREATY_NO) ELSE RTRIM(REINCO_CD + REINCO_SUB_CD) END,
               CASE WHEN LEN(RTRIM(TREATY_NO)) > 0 THEN "000" + RTRIM(TREATY_NO) ELSE RTRIM(REINCO_CD + REINCO_SUB_CD) END + CHAR(13)+ CONVERT(CHAR(10),RI_CODE_PCT) AS RI_CODE_PCT,   -- RI_CODE + SUM Insured%
               RI_PREM_PCT,   --RI Prem%
               RI_LIAB_AMT,                 
               TOTAL_PREMIUM,
               RI_COMM,                              
               START_DATE,
               END_DATE,
               ISS_BRNCH_NAME,
               RUN_DATE = GETDATE()                
     FROM      #OUTPUT
     ORDER BY  GOALS_POLICY_NO,
               BILLING_ORG_CD,
               REC_EFFECT_DATE,
               REC_EXP_DATE,               
               COVERAGE_CD,
               REIN_SEQ_NO

END
go
IF OBJECT_ID('dbo.EMMA_CHN_RPT_BULK_BOOKING') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.EMMA_CHN_RPT_BULK_BOOKING >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.EMMA_CHN_RPT_BULK_BOOKING >>>'
go
GRANT EXECUTE ON dbo.EMMA_CHN_RPT_BULK_BOOKING TO userall 
go

print "After"
go
sp_help EMMA_CHN_RPT_BULK_BOOKING
go 