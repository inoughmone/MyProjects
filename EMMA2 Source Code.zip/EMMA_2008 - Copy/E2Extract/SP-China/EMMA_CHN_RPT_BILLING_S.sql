print "Before"
go
sp_help EMMA_CHN_RPT_BILLING_S
go

IF OBJECT_ID('dbo.EMMA_CHN_RPT_BILLING_S') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.EMMA_CHN_RPT_BILLING_S
    IF OBJECT_ID('dbo.EMMA_CHN_RPT_BILLING_S') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.EMMA_CHN_RPT_BILLING_S >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.EMMA_CHN_RPT_BILLING_S >>>'
END
go
/*
****************************************************************************************************
TITLE			    : EMMA_CHN_RPT_BILLING_S
AUTHOR		    : MPHASIS SHANGHAI
DATE		      : 01/20/2007
DESCRIPTION	  : THIS STORED PROCEDURE IS USED FOR Billing Report -SUCCESSFUL.

USE FOR			  : PHD200070454
****************************************************************************************************
*/

CREATE PROCEDURE EMMA_CHN_RPT_BILLING_S
     @START_DATE         DATETIME,
     @END_DATE           DATETIME,
     @ISSUING_BRNCH_CD   CHAR(10),
     @REF_GROUP_CD       CHAR(6)   = "061000",
     @STAFF_CODE         CHAR(25)  = "STAFF-CODE",
     @REJECTION_CODE     CHAR(25) = "REJECT-CODE"      
AS
BEGIN
       
         
   CREATE TABLE #TEMP3(                 
        POLICYCERT_NO           char(14)       NULL,
        BILLING_ORG_CD          CHAR(6)        NULL,
        BILLING_TRANS_NO        INT            NULL,
        BSB_NO                  CHAR(10)       NULL,        
        ACCOUNT_NO              CHAR(20)       NULL,
        BILLING_AMT             MONEY          NULL,
        ORIGINAL_BILL_DATE      DATETIME       NULL,
        BILLING_TIMESTAMP       DATETIME       NULL
               
    )
    
    CREATE TABLE #TEMP2(                 
        POLICYCERT_NO           char(14)       NULL,
        BILLING_ORG_CD          CHAR(6)        NULL,
        BILLING_TRANS_NO        INT            NULL,        
        BILLING_AMT             MONEY          NULL,
        ORIGINAL_BILL_DATE      DATETIME       NULL
    )
                  
    CREATE TABLE #TEMP1(         
        EXT_POLICY_NO           char(14)       NULL, --master policy no                              
        POLICYCERT_NO           char(14)       NULL,
        BILLING_ORG_CD          CHAR(6)        NULL,
        BSB_NO                  CHAR(10)       NULL,
        BANK_NAME               CHAR(50)       NULL, --BSB_ADDR
        ACCOUNT_NO              CHAR(7)        NULL, -- THE FIX THREE * PLUS THE LAST FOUR ACCOUNT NUMBER           
        PREMIUM_AMT             MONEY          NULL,
        BILLING_AMT             MONEY          NULL,
        RECEIVED_AMT            MONEY          NULL,
        ORIGINAL_BILL_DATE   DATETIME       NULL,
        BILLING_DATE            DATETIME       NULL,    --TRANSACTION DATE
        BILLING_TRANS_NO        INT            NULL,            
        POLICY_HOLDER_NAME      varchar(76)    NULL,
        TSR_ID                  varchar(20)    NULL,  -- Enroller ID
        STAFF_NAME              VARCHAR(254)   NULL,  --Enroller Name
        END_EFF_DATE            DATETIME       NULL,
        PLAN_NO                 CHAR(5)        NULL,
        FIRST_BILLED_DATE       DATETIME       NULL,
        START_DATE              DATETIME       NULL,
        END_DATE                DATETIME       NULL,
        ISS_BRNCH_NAME          CHAR(45)       NULL,
        RUN_DATE                DATETIME       NULL,
        NB_COUNT                INT            NULL,
        NB_PREMIUM              MONEY          NULL,
        RN_COUNT                INT            NULL,
        RN_PREMIUM              MONEY          NULL
      )  
    
    INSERT INTO #TEMP3(
             POLICYCERT_NO,
             BILLING_ORG_CD,
             BILLING_TRANS_NO,
             BSB_NO,
             ACCOUNT_NO,
             BILLING_AMT,
             ORIGINAL_BILL_DATE,
             BILLING_TIMESTAMP
             )
    SELECT   B.POLICYCERT_NO,
             B.BILLING_ORG_CD,
             B.BILLING_TRANS_NO,
             B.BSB_NO,
             B.ACCOUNT_NO,
             B.BILLING_AMT,
             ISNULL(B.ORIGINAL_BILL_DATE,BILLED_ON_DATE) AS ORIGINAL_BILL_DATE,
             B.TIMESTAMP AS BILLING_TIMESTAMP             
    FROM     TPOLICYCERTRIDER A, 
             TBILLTRXN B,
             TBILLINGSUMMARY C               
    WHERE    CONVERT(CHAR(10),B.TIMESTAMP,111) >= @START_DATE
    AND      CONVERT(CHAR(10),B.TIMESTAMP,111) <= @END_DATE
    AND      B.REJECT_FG = 'N'
    AND      A.POLICYCERT_NO = B.POLICYCERT_NO
    AND      A.RIDER_NO = B.RIDER_NO    
    AND      A.LATEST_VERSION_FG = 'Y'
    AND      A.ISSUING_BRNCH_CD   = @ISSUING_BRNCH_CD
    AND      B.BILLING_ORG_CD = C.BILLING_ORG_CD
    AND      B.BILLING_TRANS_NO = C.BILLING_TRANS_NO
    AND      C.BILLING_STATUS_CD IN ('B','C')     
    
    INSERT INTO #TEMP2(
             POLICYCERT_NO,
             BILLING_ORG_CD,
             BILLING_TRANS_NO,
             ORIGINAL_BILL_DATE,
             BILLING_AMT)
    SELECT   POLICYCERT_NO,
             BILLING_ORG_CD,
             BILLING_TRANS_NO,
             ORIGINAL_BILL_DATE,
             SUM(BILLING_AMT)
    FROM     #TEMP3
    GROUP BY POLICYCERT_NO, BILLING_ORG_CD, BILLING_TRANS_NO, ORIGINAL_BILL_DATE
    
    INSERT INTO #TEMP1(POLICYCERT_NO,
             BILLING_ORG_CD,
             BSB_NO,
             ACCOUNT_NO,
             RECEIVED_AMT,
             ORIGINAL_BILL_DATE,
             BILLING_DATE,
             BILLING_TRANS_NO)
    SELECT   POLICYCERT_NO,
             MAX(B.BILLING_ORG_CD) AS BILLING_ORG_CD,
             MAX(BSB_NO) AS BSB_NO,
             '***' + RIGHT(MAX(B.ACCOUNT_NO),4) AS ACCOUNT_NO,                          
             SUM(B.BILLING_AMT) AS REJECTED_AMT,
             MAX(B.ORIGINAL_BILL_DATE) AS ORIGINAL_BILL_DATE,
             MAX(B.BILLING_TIMESTAMP) AS BILLING_DATE,
             MAX(B.BILLING_TRANS_NO) AS BILLING_TRANS_NO             
    FROM     #TEMP3 B
    GROUP BY POLICYCERT_NO                  
    
   
    --Get the first billed date from tpolicycertrider table
    UPDATE   #TEMP1
    SET      FIRST_BILLED_DATE = B.FIRST_BILLED_DATE,
             PLAN_NO = B.PLAN_NO,
             END_EFF_DATE = B.END_EFF_DATE             
    FROM     #TEMP1 A, TPOLICYCERTRIDER B
    WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO          
    AND      B.LATEST_VERSION_FG = 'Y'
    AND      B.RIDER_NO = 0
    
    --Get the NB and RN infomation 
    UPDATE   #TEMP1
    SET      NB_COUNT =  (SELECT   COUNT(*)
                          FROM     #TEMP2 A,#TEMP1 B
                          WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
                          AND      A.BILLING_ORG_CD = B.BILLING_ORG_CD
                          AND      A.BILLING_TRANS_NO = B.BILLING_TRANS_NO
                          AND      A.ORIGINAL_BILL_DATE = B.FIRST_BILLED_DATE
                          )
    
    UPDATE   #TEMP1
    SET      NB_PREMIUM =(SELECT   SUM(A.BILLING_AMT)
                          FROM     #TEMP2 A,#TEMP1 B
                          WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
                          AND      A.BILLING_ORG_CD = B.BILLING_ORG_CD
                          AND      A.BILLING_TRANS_NO = B.BILLING_TRANS_NO
                          AND      A.ORIGINAL_BILL_DATE = B.FIRST_BILLED_DATE
                          )

    UPDATE   #TEMP1
    SET      RN_COUNT =  (SELECT   COUNT(DISTINCT A.POLICYCERT_NO)
                          FROM     #TEMP2 A,#TEMP1 B
                          WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
                          AND      A.BILLING_ORG_CD = B.BILLING_ORG_CD
                          AND      A.BILLING_TRANS_NO = B.BILLING_TRANS_NO
                          AND      A.ORIGINAL_BILL_DATE > B.FIRST_BILLED_DATE
                          )
    
    UPDATE   #TEMP1
    SET      RN_PREMIUM =(SELECT   SUM(A.BILLING_AMT)
                          FROM     #TEMP2 A,#TEMP1 B
                          WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
                          AND      A.BILLING_ORG_CD = B.BILLING_ORG_CD
                          AND      A.BILLING_TRANS_NO = B.BILLING_TRANS_NO
                          AND      A.ORIGINAL_BILL_DATE > B.FIRST_BILLED_DATE
                          )
                          
    --Get the billing amount
    UPDATE    #TEMP1
    SET       BILLING_AMT = (SELECT   SUM(B.BILLING_AMT)
                             FROM     TBILLTRXN B
                             WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
                             AND      A.BILLING_TRANS_NO = B.BILLING_TRANS_NO
                             AND      A.BILLING_ORG_CD = B.BILLING_ORG_CD)
    FROM      #TEMP1 A
    
    --Get the master policy
    UPDATE   #TEMP1
    SET      EXT_POLICY_NO  = (  SELECT C.EXT_POLICY_NO
                                FROM TPLANDETS C
                                WHERE C.PLAN_NO = A.PLAN_NO
                                AND C.END_EFF_DATE = (SELECT   MAX(D.END_EFF_DATE)
                                                       FROM    TPLANDETS D
                                                      WHERE    D.PLAN_NO = C.PLAN_NO
                                                       AND     D.END_EFF_DATE <= A.END_EFF_DATE))
    FROM      #TEMP1 A
    
    --Get the bank name
    UPDATE   #TEMP1
    SET      BANK_NAME = B.BSB_ADDR
    FROM     #TEMP1 A, TBANKBRANCH B
    WHERE    A.BSB_NO = B.BSB_NO
    
    --Get the policy period premium
    UPDATE   #TEMP1
    SET      PREMIUM_AMT = B.PRM_PER_PERIOD_AMT
    FROM     #TEMP1 A, TPOLICYCERT B
    WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
    
    SELECT   A.POLICYCERT_NO,PREMIUM_AMT = SUM(B.PRM_PER_PERIOD_AMT)
    INTO     #TEMP6
    FROM     #TEMP1 A, TPOLICYCERTRIDER B
    WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
    AND      A.PREMIUM_AMT <= 0
    AND      B.STATUS_CD = 'A'
    AND      B.END_EFF_DATE = (SELECT MAX(C.END_EFF_DATE) 
                               FROM   TPOLICYCERTRIDER C 
                               WHERE  C.POLICYCERT_NO = A.POLICYCERT_NO
                               AND    C.END_EFF_DATE < A.END_EFF_DATE)
    GROUP BY  A.POLICYCERT_NO
    
    UPDATE   #TEMP1
    SET      PREMIUM_AMT = B.PREMIUM_AMT
    FROM     #TEMP1 A,#TEMP6 B
    WHERE    A.POLICYCERT_NO = B.POLICYCERT_NO
        
    -- Get the policy holder name
    UPDATE    #TEMP1
    SET       POLICY_HOLDER_NAME = LTRIM(RTRIM(B.PHOLD_FAMILY_NAME + " " + B.PHOLD_GIVEN_NAME))
    FROM      #TEMP1 A, TPOLICYCERTHOLDER B,TPOLICYCERT C
    WHERE     A.POLICYCERT_NO = C.POLICYCERT_NO
    AND       C.POLICY_HOLDER_NO = B.POLICY_HOLDER_NO
    
   
    
    --Get the staff name from policycert ext.
    UPDATE   #TEMP1    
    SET      TSR_ID = B.POL_STAFF_CD
    FROM     #TEMP1 A,
             TPOLICYCERT_EXT B
    WHERE    B.POLICYCERT_NO = A.POLICYCERT_NO
    AND      B.END_EFF_DATE  = A.END_EFF_DATE
    AND      B.RIDER_NO = 0
        
    UPDATE   #TEMP1    
    SET      STAFF_NAME = C.ELE_VALUE_DESC_TXT
    FROM     #TEMP1 A,             
             TREFTAB C
    WHERE    C.REF_GROUP_CD = @REF_GROUP_CD
    AND      C.DATA_ELEMENT_NAME = @STAFF_CODE
    AND      ltrim(rtrim(C.DATA_ELEMENT_CODE)) = A.TSR_ID
       
    -- Get the extra fields for the report needs.
    UPDATE    #TEMP1
    SET       START_DATE = @START_DATE,
              END_DATE = @END_DATE,
              RUN_DATE = GETDATE()
    
    UPDATE    #TEMP1
    SET       ISS_BRNCH_NAME = (SELECT ISS_BRNCH_NAME 
                                 FROM TISSUEBRANCH 
                                 WHERE ISSUING_BRNCH_CD = @ISSUING_BRNCH_CD)
    -- Export the records                                
    SELECT     EXT_POLICY_NO,  
               POLICYCERT_NO,
               BILLING_ORG_CD,
               ISNULL(BANK_NAME,'N/A') AS BANK_NAME,
               ACCOUNT_NO,
               PREMIUM_AMT,
               BILLING_AMT,
               RECEIVED_AMT,
               ORIGINAL_BILL_DATE,
               BILLING_DATE,
               BILLING_TRANS_NO,           
               POLICY_HOLDER_NAME,
               ISNULL(STAFF_NAME,'N/A') AS STAFF_NAME,
               START_DATE        ,
               END_DATE          ,
               ISS_BRNCH_NAME    ,
               RUN_DATE,
               NB_COUNT,
               NB_PREMIUM,
               RN_COUNT,
               RN_PREMIUM                    
     FROM      #TEMP1      
     ORDER BY  EXT_POLICY_NO,POLICYCERT_NO

END
go
IF OBJECT_ID('dbo.EMMA_CHN_RPT_BILLING_S') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.EMMA_CHN_RPT_BILLING_S >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.EMMA_CHN_RPT_BILLING_S >>>'
go
GRANT EXECUTE ON dbo.EMMA_CHN_RPT_BILLING_S TO userall 
go

print "After"
go
sp_help EMMA_CHN_RPT_BILLING_S
go
