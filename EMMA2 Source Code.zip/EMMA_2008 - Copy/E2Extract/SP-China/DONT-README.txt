For Report Extract
Kindly use the sp stored being used by the Print Engine.